package com.slipkprojects.sockshttp.util;

import android.content.Context;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class FetchColumnAsync extends AsyncTask<String, Void, String>  
{
    private Context mContext;

    public FetchColumnAsync( Context ctx){
		this.mContext = ctx; 
    }

    protected String doInBackground(String... urls)
    {
		String fullString = "";
		try{

			URL url = new URL(urls[0]);
			BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				fullString += line;
			}
			reader.close();
        }catch(Exception e ){
			e.getMessage();
        }

        return fullString;
    }

    @Override
    protected void onPostExecute(String value){
		try{
			((OnValueFetchedListener) mContext).onValueFetched(value);
		}catch(ClassCastException e){}
    }

    public interface OnValueFetchedListener{
        void onValueFetched(String columns);
    }

}
