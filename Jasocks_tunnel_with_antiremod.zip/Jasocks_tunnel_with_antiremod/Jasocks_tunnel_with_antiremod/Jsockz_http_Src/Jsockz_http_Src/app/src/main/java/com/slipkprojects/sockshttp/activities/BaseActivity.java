package com.slipkprojects.sockshttp.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import com.slipkprojects.sockshttp.preference.LocaleHelper;
import java.io.DataOutputStream;
import java.io.IOException;
import com.slipkprojects.ultrasshservice.SocksHttpService.ConnectionStats;
import static android.content.pm.PackageManager.GET_META_DATA;
import com.slipkprojects.ultrasshservice.SocksHttpService;

public abstract class BaseActivity extends AppCompatActivity
{
	public static int mTheme = 0;
    private static SharedPreferences sharedPreferences;
	private SocksHttpService mBoundService = null;
	private static SharedPreferences sharedPreference;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		//setTheme(ThemeUtil.getThemeId(mTheme));
		
		//setModoNoturnoLocal();
			
		resetTitles();
	}
	
	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(LocaleHelper.setLocale(base));
	}
	
	/*public void setModoNoturnoLocal() {
		boolean is = new Settings(this)
			.getModoNoturno().equals("on");

		int night_mode = is ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO;
		//AppCompatDelegate.setDefaultNightMode(night_mode);
		getDelegate().setLocalNightMode(night_mode);
	}*/
	protected boolean is_active() {
        if (this.mBoundService == null || !this.mBoundService.is_active()) {
            return false;
        }
        return true;
    }
	
	
	protected void resetTitles() {
		try {
			ActivityInfo info = getPackageManager().getActivityInfo(getComponentName(), GET_META_DATA);
			if (info.labelRes != 0) {
				setTitle(info.labelRes);
			}
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public static SharedPreferences getSharedPreferences()
    {
        return sharedPreferences;
    }

	public static SharedPreferences getDefSharedPreferences()
    {
        return sharedPreference;
    }

	public static Boolean isDarkTheme() {
		return sharedPreference.getBoolean("use_dark_theme", false);
	}

	public static boolean runCommand(String command)
	{
		java.lang.Process process = null;
		DataOutputStream os = null;
		try
		{
			process = Runtime.getRuntime().exec("sh");
			try
			{

				os = new DataOutputStream(process.getOutputStream());
				os.writeBytes(command + "\n");
				os.writeBytes("exit\n");
				os.flush();
				process.waitFor();
				return true;
			}
			catch (Exception e)
			{

				Log.d("", e.getMessage());
				return false;

			}
			finally
			{
				try
				{
					if (os != null)
					{
						os.close();
					}
					process.destroy();
				}
				catch (IOException e)
				{
					// nothing
				}
			}
		}
		catch (IOException e)
		{
			Log.d("", e.getMessage());
			//SnapData.getSnapData().addLog(e.getMessage());
			return false;

		}
		finally
		{
			try
			{
				if (os != null)
				{
					os.close();
				}
				process.destroy();
			}
			catch (Exception e)
			{
				// nothing
			}
		}

	}
	
}
