package com.slipkprojects.sockshttp.utils;

import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.ConnectivityManager;
import android.telephony.TelephonyManager;
import android.content.Context;

public class VPNNetworkUtils
{

	public static int getAPN()
	{
		// TODO: Implement this method
		return 0;
	}
	public static String getNetworkType(Context context) {
		TelephonyManager mTelephonyManager = (TelephonyManager)
			context.getSystemService(Context.TELEPHONY_SERVICE);
		int networkType = mTelephonyManager.getNetworkType();
		switch (networkType) {
			case TelephonyManager.NETWORK_TYPE_GPRS:
			case TelephonyManager.NETWORK_TYPE_EDGE:
			case TelephonyManager.NETWORK_TYPE_CDMA:
			case TelephonyManager.NETWORK_TYPE_1xRTT:
			case TelephonyManager.NETWORK_TYPE_IDEN:
				return "2G";
			case TelephonyManager.NETWORK_TYPE_UMTS:
			case TelephonyManager.NETWORK_TYPE_EVDO_0:
			case TelephonyManager.NETWORK_TYPE_EVDO_A:
				//
			case TelephonyManager.NETWORK_TYPE_HSDPA:
			case TelephonyManager.NETWORK_TYPE_HSUPA:
			case TelephonyManager.NETWORK_TYPE_HSPA:
			case TelephonyManager.NETWORK_TYPE_EVDO_B:
			case TelephonyManager.NETWORK_TYPE_EHRPD:
			case TelephonyManager.NETWORK_TYPE_HSPAP:
				//
				return "3G";
			case TelephonyManager.NETWORK_TYPE_LTE:
				//
				return "4G";
			default:
				return "No Network Detected";
		}
	}
	
	public static String getNetwork(Context context) {

		TelephonyManager teleMan = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		int networkType = teleMan.getNetworkType();
		switch ( networkType ) {
			case TelephonyManager.NETWORK_TYPE_1xRTT:
				return "1xRTT";
			case TelephonyManager.NETWORK_TYPE_CDMA:
				return "CDMA";
			case TelephonyManager.NETWORK_TYPE_EDGE:
				return "EDGE";
			case TelephonyManager.NETWORK_TYPE_EHRPD:
				return "eHRPD";
			case TelephonyManager.NETWORK_TYPE_EVDO_0:
				return "EVDO rev. 0";
			case TelephonyManager.NETWORK_TYPE_EVDO_A:
				return "EVDO rev. A";
			case TelephonyManager.NETWORK_TYPE_EVDO_B:
				return "EVDO rev. B";
			case TelephonyManager.NETWORK_TYPE_GPRS:
				return "GPRS";
			case TelephonyManager.NETWORK_TYPE_HSDPA:
				return "HSDPA";
			case TelephonyManager.NETWORK_TYPE_HSPA:
				return "HSPA";
			case TelephonyManager.NETWORK_TYPE_HSPAP:
				return "HSPA+";
			case TelephonyManager.NETWORK_TYPE_HSUPA:
				return "HSUPA";
			case TelephonyManager.NETWORK_TYPE_IDEN:
				return "iDen";
			case TelephonyManager.NETWORK_TYPE_LTE:
				return "LTE";
			case TelephonyManager.NETWORK_TYPE_UMTS:
				return "UMTS";
			case TelephonyManager.NETWORK_TYPE_UNKNOWN:
				return "Unknown";
		}
		return "New type of network";
	}
	public static String getAPN(Context context){
		String extrainfo = "";
		String subtype = "";
		ConnectivityManager connManager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
		NetworkInfo net = connManager.getActiveNetworkInfo();
		if(net == null) {
			subtype = "Unknown";
			extrainfo = "Unknown";

		} else {
			subtype = net.getSubtypeName();
			if(subtype == null) {
				subtype = "";
			}

			extrainfo = net.getExtraInfo();
			if(extrainfo == null) {
				extrainfo = "";
			}

		}
		return extrainfo;
	}
	
	public static String getSubType(Context context){
		String extrainfo = "";
		String subtype = "";
		ConnectivityManager connManager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
		NetworkInfo net = connManager.getActiveNetworkInfo();
		if(net == null) {
			subtype = "Unknown";
			extrainfo = "Unknown";

		} else {
			subtype = net.getSubtypeName();
			if(subtype == null) {
				subtype = "";
			}

			extrainfo = net.getExtraInfo();
			if(extrainfo == null) {
				extrainfo = "";
			}

		}
		return subtype;
	}
	
	public static String getReason(Context context){
		ConnectivityManager connManager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
		NetworkInfo net = connManager.getActiveNetworkInfo();
		String net_reason = "";
		if(net != null && net.isConnected()){
			net_reason = "connected";
		}else{
			net_reason = "dataDisabled";
		}
		return net_reason;
	}
	
	public static String getType(Context context){
		ConnectivityManager connManager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
		NetworkInfo net = connManager.getActiveNetworkInfo();
		String net_reason = "";
		if(net != null && net.isConnected()){
			net_reason = net.getTypeName();
		}else{
			net_reason = "Recognizing…";
		}
		return net_reason;
	}
	
	public static String getState(Context context){
		ConnectivityManager connManager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
		NetworkInfo net = connManager.getActiveNetworkInfo();
		String net_reason = "";
		if(net != null && net.isConnected()){
			net_reason = "CONNECTED";
		}else{
			net_reason = "Failed";
		}
		return net_reason;
	}
}
