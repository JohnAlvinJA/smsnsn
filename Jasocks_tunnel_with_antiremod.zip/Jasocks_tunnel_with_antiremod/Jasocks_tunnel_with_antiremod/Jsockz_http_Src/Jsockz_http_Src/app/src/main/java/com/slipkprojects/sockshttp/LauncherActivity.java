package com.slipkprojects.sockshttp;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import com.jasocks.tunnel.R;
/**
 * @author anuragdhunna
 */
public class LauncherActivity extends AppCompatActivity
{
	public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        window.setFormat(PixelFormat.RGBA_8888);
    }

    Thread splashTread;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jsockz_launcher);
		StartAnimations();
	}

    private void StartAnimations() {
		Animation animation = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        animation.reset();
		TextView appName=(TextView) findViewById(R.id.text_launcher);
        appName.clearAnimation();
        appName.startAnimation(animation);
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        anim.reset();
        TextView l=(TextView) findViewById(R.id.text_launcher);
        l.clearAnimation();
        l.startAnimation(anim);
		Animation anims = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        anims.reset();
        anims = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        anims.reset();
        ImageView iv = (ImageView) findViewById(R.id.image_launcher);
        iv.clearAnimation();
        iv.startAnimation(anims);
        

        splashTread = new Thread() {
            @Override
            public void run() {
                try {
                    int waited = 0;
                    // Splash screen pause time
                    while (waited < 500) {
                        sleep(100);
                        waited += 100;
                    }
                    Intent intent = new Intent(LauncherActivity.this,
											   SocksHttpMainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                    LauncherActivity.this.finish();
                } catch (InterruptedException e) {
                    // do nothing
                } finally {
                    LauncherActivity.this.finish();
                }

            }
        };
        splashTread.start();

    }

}
