package com.slipkprojects.sockshttp;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.icu.text.DecimalFormat;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Chronometer.OnChronometerTickListener;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.github.mikephil.charting.charts.LineChart;
import com.jasocks.tunnel.R;
import com.slipkprojects.sockshttp.SocksHttpApp;
import com.slipkprojects.sockshttp.activities.ConfigExportFileActivity;
import com.slipkprojects.sockshttp.activities.ConfigGeralActivity;
import com.slipkprojects.sockshttp.activities.ConfigImportFileActivity;
import com.slipkprojects.sockshttp.activities.HostChecker;
import com.slipkprojects.sockshttp.adapter.LogsAdapter;
import com.slipkprojects.sockshttp.fragments.ClearConfigDialogFragment;
import com.slipkprojects.sockshttp.fragments.ProxyRemoteDialogFragment;
import com.slipkprojects.sockshttp.model.ExceptionHandler;
import com.slipkprojects.sockshttp.util.FetchColumnAsync;
import com.slipkprojects.sockshttp.util.GoogleFeedbackUtils;
import com.slipkprojects.sockshttp.util.StoredData;
import com.slipkprojects.sockshttp.util.Utils;
import com.slipkprojects.sockshttp.view.ArmorGraph;
import com.slipkprojects.sockshttp.view.GraphHelper;
import com.slipkprojects.sockshttp.view.ITrafficSpeedListener;
import com.slipkprojects.sockshttp.view.TrafficSpeedMeasurer;
import com.slipkprojects.ultrasshservice.LaunchVpn;
import com.slipkprojects.ultrasshservice.SocksHttpService;
import com.slipkprojects.ultrasshservice.config.ConfigParser;
import com.slipkprojects.ultrasshservice.config.Settings;
import com.slipkprojects.ultrasshservice.logger.ConnectionStatus;
import com.slipkprojects.ultrasshservice.logger.SkStatus;
import com.slipkprojects.ultrasshservice.tunnel.TunnelManagerHelper;
import com.slipkprojects.ultrasshservice.tunnel.TunnelUtils;
import com.slipkprojects.ultrasshservice.util.SkProtect;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONObject;
import vmodz.signaturechecker.status404error.CheckSign;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

/**
 * Activity Principal
 * @author SlipkHunter
 */

public class SocksHttpMainActivity extends AppCompatActivity
	implements DrawerLayout.DrawerListener,
			View.OnClickListener, RadioGroup.OnCheckedChangeListener,
CompoundButton.OnCheckedChangeListener, SkStatus.StateListener, FetchColumnAsync.OnValueFetchedListener
{

	public static String ans;
	
	private TextView MsG;
	LinearLayout mLinearLayout;
	LinearLayout mLinearLayoutHeader;
	LinearLayout cLinearLayout;
	LinearLayout cLinearLayoutHeader;
	private CheckSign cs;
	public String jsockzhttps = new String(new byte[]{74,115,111,99,107,122,124,104,116,116,112});
	public String jasockstunnel = new String(new byte[]{74,65,115,111,99,107,115,124,84,117,110,110,101,108});
	private static final String TAG = SocksHttpMainActivity.class.getSimpleName();
	private static String MSGadmn = "https://raw.githubusercontent.com/john-alvin-escobido/test/main/JAsocks%7Ctunnel%20message";
	private static final String UPDATE_VIEWS = "MainUpdate";
	public static final String OPEN_LOGS = "com.slipkprojects.sockshttp:openLogs";
	private LinearLayout graphClose;
	private LinearLayout GraphView;
	private SwitchCompat showGraph;
	private TextView mTextViewCountDown;
	public static SwitchCompat ReconnectSwitch;
	private Button mButtonStartPause;
	private Button mButtonReset;
	private CountDownTimer mCountDownTimer;
	private boolean mTimerRunning;
	private long mStartTimeInMillis;
	private long mTimeLeftInMillis;
	private long mEndTime;
	private EditText mEditTextInput;
	private LinearLayout AutoOn;
	protected List<Long> dList;
    protected List<Long> uList;
	private LineChart mChart;
	private GraphHelper graph;
	private DrawerPanel mDrawerPanel;
	private Thread dataThread;
	private Settings mConfig;
	private Toolbar toolbar_main;
	private TabLayout tablayout;
	private ViewPager viewpager;
	private RecyclerView logList;
	private LogsAdapter mLogAdapter;
	private FloatingActionButton deleteLogs;
	private Handler mHandler;
	private LinearLayout mainLayout;
	private LinearLayout loginLayout;
	private LinearLayout proxyInputLayout;
	private TextView proxyText;
	private RadioGroup metodoConexaoRadio;
	private LinearLayout payloadLayout;
	private TextInputEditText payloadEdit;
	private SwitchCompat customPayloadSwitch;
	private Button starterButton;
	private ImageButton inputPwShowPass;
	private TextInputEditText inputPwUser;
	private TextInputEditText inputPwPass;
	private android.support.v7.widget.CardView ViewMessage;
	private android.support.v7.widget.CardView Viewgone;
	private android.support.v7.widget.CardView ViewGone;
	private android.support.v7.widget.CardView statistics;
	private LinearLayout configMsgLayout;
	private TextView configMsgText;
	public static TextView status;
	private LinearLayout PayloadLock;
	private LinearLayout ConnectionClose;
	public TextView Bytes;
	public TextView wifi_mobile;
	public TextView LocalIP;
	final double [] RXOld = new double [1];
	private static final boolean SHOW_SPEED_IN_BITS = false;
    private TrafficSpeedMeasurer mTrafficSpeedMeasurer;
    private TextView SpeedBytes_In;
	private TextView SpeedBytes_Out;
	private ImageView mArrow1;
	private ImageView cArrow1;
	private Thread dataUpdate;
	private Handler vHandler = new Handler();
	private String mTransientAuthPW;
	Chronometer cmTimer;
    Button btnStart, btnStop, btnReset;
	private SharedPreferences sharedPreferences;
	private TextView ExternalIP;
    Boolean resume = false;
    long elapsedTime;
	private LinearLayout ProgressView;
	public static TextView progress_status;
	private ProgressBar progressBar;
	private int progressStatus = 0;
    private Handler handler = new Handler();
	private ViewPager Vpager;
	private TabLayout tabs;
	JSONObject jsonObject;
    String s;
	private TextView m_totalReceivedView;
	private TextView m_trafficReceivedView;
	View mView;
	Button btnHit;
	TextView MsgAdmin;
ProgressDialog pd;
    
    
	
	
	@Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		mHandler = new Handler();
		mConfig = new Settings(this);
		//mDrawer = new DrawerLog(this);
		mDrawerPanel = new DrawerPanel(this);
		
		SharedPreferences prefs = getSharedPreferences(SocksHttpApp.PREFS_GERAL, Context.MODE_PRIVATE);
		
		
		boolean showFirstTime = prefs.getBoolean("connect_first_time", true);
		int lastVersion = prefs.getInt("last_version", 0);
		
		
		
		
		
		// se primeira vez
		if (showFirstTime)
        {
            SharedPreferences.Editor pEdit = prefs.edit();
            pEdit.putBoolean("connect_first_time", false);
            pEdit.apply();

			Settings.setDefaultConfig(this);

			showBoasVindas();
        }

		try {
			int idAtual = ConfigParser.getBuildId(this);

			if (lastVersion < idAtual) {
				SharedPreferences.Editor pEdit = prefs.edit();
				pEdit.putInt("last_version", idAtual);
				pEdit.apply();

				// se estiver atualizando
				if (!showFirstTime) {
					if (lastVersion <= 12) {
						Settings.setDefaultConfig(this);
						Settings.clearSettings(this);

						Toast.makeText(this, "As configurações foram limpas para evitar bugs",
							Toast.LENGTH_LONG).show();
							
							
					}
				}

			}
		} catch(IOException e) {}
		
		
		// set layout
		doLayout();

		// verifica se existe algum problema
		SkProtect.CharlieProtect();

		// recebe local dados
		IntentFilter filter = new IntentFilter();
		filter.addAction(UPDATE_VIEWS);
		filter.addAction(OPEN_LOGS);
		
		LocalBroadcastManager.getInstance(this)
			.registerReceiver(mActivityReceiver, filter);
			
		doUpdateLayout();
	}


	/**
	 * Layout
	 */
	 
	
	
	 
	private void showPayloadGenerator() {
		PayloadGenerator payloadGenerator = new PayloadGenerator(this);
		payloadGenerator.setDialogTitle("Payload Generator");
		payloadGenerator.setGenerateListener("Generate", new PayloadGenerator.OnGenerateListener() {
				@Override
				public void onGenerate(String payloadGenerated) {
					payloadEdit.setText(payloadGenerated);
				}
			});
		payloadGenerator.show();
	}
	
	private void doLayout() {
		setContentView(R.layout.activity_main_drawer);
		if(getPackageName().equals (jasockstunnel)){
			if(getTitle().equals (jsockzhttps)){
			setContentView(R.layout.activity_main_drawer);
			
            
		}else{finish();}}
		toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		toolbar_main.setTitle(jasockstunnel);
		toolbar_main.setSubtitle(getPackageName());
		mDrawerPanel.setDrawer(toolbar_main);
		setSupportActionBar(toolbar_main);
		getSupportActionBar().setElevation(0);
		String[] pages = {"MAIN","LOG","STATS","ABOUT"};
		Vpager = (ViewPager)findViewById(R.id.viewpager);
		tabs = (TabLayout)findViewById(R.id.tablayout);
		Vpager.setAdapter(new TabAdapter(Arrays.asList(pages)));
		Vpager.setOffscreenPageLimit(3);
		tabs.setTabMode(TabLayout.MODE_FIXED);
		tabs.setTabGravity(TabLayout.GRAVITY_FILL);
		tabs.setupWithViewPager(Vpager);
		SpeedBytes_In = (TextView) findViewById(R.id.bytes_in);
		SpeedBytes_Out = (TextView) findViewById(R.id.bytes_out);
        mTrafficSpeedMeasurer = new TrafficSpeedMeasurer(TrafficSpeedMeasurer.TrafficType.ALL);
        mTrafficSpeedMeasurer.startMeasuring();
		mainLayout = (LinearLayout) findViewById(R.id.activity_mainLinearLayout);
		loginLayout = (LinearLayout) findViewById(R.id.activity_mainInputPasswordLayout);
		starterButton = (Button) findViewById(R.id.activity_starterButtonMain);
		AutoOn = (LinearLayout) findViewById(R.id.autoOn);
		inputPwUser = (TextInputEditText) findViewById(R.id.activity_mainInputPasswordUserEdit);
		inputPwPass = (TextInputEditText) findViewById(R.id.activity_mainInputPasswordPassEdit);
		PayloadLock = (LinearLayout) findViewById(R.id.payloadlock);
		inputPwShowPass = (ImageButton) findViewById(R.id.activity_mainInputShowPassImageButton);
		mChart = (LineChart) findViewById(R.id.chart1);
		graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.graphColor))).chart(mChart);
		((TextView) findViewById(R.id.activity_mainAutorText))
			.setOnClickListener(this);

		
		cs = new CheckSign(this);
		cs.setSHA1("61:ed:37:7e:85:d3:86:a8:df:ee:6b:86:4b:d8:5b:0b:fa:a5:af:81");
		cs.check();
		
		
		proxyInputLayout = (LinearLayout) findViewById(R.id.activity_mainInputProxyLayout);
		proxyText = (TextView) findViewById(R.id.activity_mainProxyText);
		ExternalIP=(TextView)findViewById(R.id.external_ip);
		/*Spinner spinnerTunnelType = (Spinner) findViewById(R.id.activity_mainTunnelTypeSpinner);
		String[] items = new String[]{"SSH DIRECT", "SSH + PROXY", "SSH + SSL (beta)"};
		//create an adapter to describe how the items are displayed, adapters are used in several places in android.
		//There are multiple variations of this, but this is the basic variant.
		ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
		//set the spinners adapter to the previously created one.
		spinnerTunnelType.setAdapter(adapter);*/
		ConnectionClose = (LinearLayout) findViewById(R.id.connectionClose);
		graphClose = (LinearLayout) findViewById(R.id.closeGraph);
		metodoConexaoRadio = (RadioGroup) findViewById(R.id.activity_mainMetodoConexaoRadio);
		customPayloadSwitch = (SwitchCompat) findViewById(R.id.activity_mainCustomPayloadSwitch);
		ReconnectSwitch = (SwitchCompat) findViewById(R.id.autoReconnect);
		starterButton.setOnClickListener(this);
		proxyInputLayout.setOnClickListener(this);
		GraphView = (LinearLayout) findViewById(R.id.graphView);
		payloadLayout = (LinearLayout) findViewById(R.id.activity_mainInputPayloadLinearLayout);
		payloadEdit = (TextInputEditText) findViewById(R.id.activity_mainInputPayloadEditText);
		statistics = (android.support.v7.widget.CardView) findViewById(R.id.stats_on);
		ViewGone = (android.support.v7.widget.CardView) findViewById(R.id.Viewgone);
		Viewgone = (android.support.v7.widget.CardView) findViewById(R.id.Vgone);
		ViewMessage = (android.support.v7.widget.CardView) findViewById(R.id.view_message);
		configMsgLayout = (LinearLayout) findViewById(R.id.activity_mainMensagemConfigLinearLayout);
		configMsgText = (TextView) findViewById(R.id.activity_mainMensagemConfigTextView);
		mEditTextInput=(EditText)findViewById(R.id.times);
		wifi_mobile = (TextView) findViewById(R.id.netType);
		LocalIP = (TextView) findViewById(R.id.IPaddress);
		sharedPreferences = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
		cmTimer = (Chronometer) findViewById(R.id.cmTimer);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        btnReset = (Button) findViewById(R.id.btnReset);
		
		MsG = (TextView) findViewById(R.id.message_update);
		MsgAdmin = (TextView) findViewById(R.id.admin_msg);
		progress_status = (TextView) findViewById(R.id.Pstatus);
		progressBar = (ProgressBar) findViewById(R.id.ProgressBarconnection);
		ProgressView = (LinearLayout) findViewById(R.id.progress_view);
		mTextViewCountDown = (TextView) findViewById(R.id.duration);
		status = (TextView) findViewById(R.id.connection_status);
		showGraph = (SwitchCompat) findViewById(R.id.showgraph);
		LinearLayoutManager layoutManager = new LinearLayoutManager(this);
		deleteLogs = (FloatingActionButton)findViewById(R.id.delete_log);
		mLogAdapter = new LogsAdapter(layoutManager,this);
		logList = (RecyclerView) findViewById(R.id.recyclerLog);
		logList.setAdapter(mLogAdapter);
		logList.setLayoutManager(layoutManager);
		status.setTextColor(getResources().getColor(R.color.connected));
		mLogAdapter.scrollToLastPosition();
		mEditTextInput.setText("55");
		statistics.setVisibility(8);
		ViewMessage.setVisibility(8);
		GraphView.setVisibility(8);
		graphClose.setVisibility(8);
		ConnectionClose.setVisibility(0);
		Vpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
				@Override
				public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
					invalidateOptionsMenu();
				}

				@Override
				public void onPageSelected(int position) {

				}

				@Override
				public void onPageScrollStateChanged(int state) {

				}
			});
		
		if (!StoredData.isSetData)
		{
			StoredData.setZero();
		}
		if (mConfig.getPrefsPrivate().getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			if (mConfig.getPrefsPrivate().getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				inputPwUser.setText(mConfig.getPrivString(Settings.USUARIO_KEY));
				inputPwPass.setText(mConfig.getPrivString(Settings.SENHA_KEY));
			}
		}
		else {
			payloadEdit.setText(mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY));
		}

		metodoConexaoRadio.setOnCheckedChangeListener(this);
		customPayloadSwitch.setOnCheckedChangeListener(this);
		inputPwShowPass.setOnClickListener(this);
		getPublicIP();
		this.liveData();
		showAgradecimentos();
		deleteLogs.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					mLogAdapter.clearLog();
				}
		});
		
		try {
			PackageInfo pm = getPackageManager().getPackageInfo(getPackageName(), 0);
			String version = String.format("%s (Build %d)", pm.versionName, pm.versionCode);

			TextView versionName = (TextView) findViewById(R.id.versionName);
			versionName.setText(version);
		} catch (PackageManager.NameNotFoundException e) {}

		Button showLicense = (Button) findViewById(R.id.activity_aboutShowLicenseButton);
		showLicense.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showLicenses();
				}
			});
		
		cArrow1 = (ImageView)findViewById(R.id.cArrowDown);
		cArrow1.animate().setDuration(500).rotation(180);
		cLinearLayout = (LinearLayout) findViewById(R.id.message_layout_expand);
		cLinearLayout.setVisibility(View.GONE);
		cLinearLayoutHeader = (LinearLayout) findViewById(R.id.check_config_message_layout_header);
		cLinearLayoutHeader.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					if (cLinearLayout.getVisibility()==View.GONE){
						expanded();
					}else{
						collapsing();
					}
				}
			});
		mArrow1 = (ImageView)findViewById(R.id.mArrowDown);
		mArrow1.animate().setDuration(500).rotation(180);
		mLinearLayout = (LinearLayout) findViewById(R.id.expandable);
		mLinearLayout.setVisibility(View.GONE);
		mLinearLayoutHeader = (LinearLayout) findViewById(R.id.header);
		mLinearLayoutHeader.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					if (mLinearLayout.getVisibility()==View.GONE){
						expand();
					}else{
						collapse();
					}
				}
			});
		final SharedPreferences sharedPreferences = getSharedPreferences("conditionCheck", MODE_PRIVATE); 
		showGraph.setChecked(sharedPreferences.getBoolean("switchCondition",false));        
		showGraph.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {            
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					final SharedPreferences sharedPreferences = getSharedPreferences("conditionCheck", MODE_PRIVATE);
					SharedPreferences.Editor editor = sharedPreferences.edit();
					if (showGraph.isChecked()) {
					//	Toast.makeText(getApplicationContext(), "Checked Condition True", Toast.LENGTH_LONG).show();
						editor.putBoolean("switchCondition",showGraph.isChecked());
						editor.commit();    
						showGraph.setText(R.string.hide);
						showGraph.setChecked(true);
						GraphView.setVisibility(0);
						Animation aniFade = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.pop_up);
						GraphView.startAnimation(aniFade);
						
					} else {
				//		Toast.makeText(getApplicationContext(), "Checked Condition False", Toast.LENGTH_LONG).show();
						editor.putBoolean("switchCondition",showGraph.isChecked());
						editor.commit();
						showGraph.setText(R.string.show);
						showGraph.setChecked(false);
						GraphView.setVisibility(8);
						Animation aniFade = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.pop_off);
						GraphView.startAnimation(aniFade);
						//Graphs.setVisibility(8);
					}
				}
			});
		
		final SharedPreferences sharedPreference = getSharedPreferences("reconnect", MODE_PRIVATE); 
		ReconnectSwitch.setChecked(sharedPreference.getBoolean("autoSwitch",false));   
		ReconnectSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
			{
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					final SharedPreferences sharedPreference = getSharedPreferences("reconnect", MODE_PRIVATE);
					SharedPreferences.Editor editors = sharedPreference.edit();
					if(ReconnectSwitch.isChecked()){
						editors.putBoolean("autoSwitch",ReconnectSwitch.isChecked());
						editors.commit();    
						ReconnectSwitch.setChecked(true);
						AutoOn.setVisibility(0);
						Toast.makeText(SocksHttpMainActivity.this, "Auto Reconnect is ON", Toast.LENGTH_SHORT).show();
						mTextViewCountDown.setVisibility(0);
					}else {
						editors.putBoolean("autoSwitch",ReconnectSwitch.isChecked());
						editors.commit();
						ReconnectSwitch.setChecked(false);
						AutoOn.setVisibility(8);
						Toast.makeText(SocksHttpMainActivity.this, "Auto Reconnect is OFF", Toast.LENGTH_SHORT).show();
						mTextViewCountDown.setVisibility(8);
					}
					
					String input = mEditTextInput.getText().toString();
					if (input.length() == 0) {
					//	Toast.makeText(SocksHttpMainActivity.this, "Restart the App for default connection method", Toast.LENGTH_SHORT).show();
						return;
					}
					long millisInput = Long.parseLong(input) * 1000;
					if (millisInput == 0) {
					//	Toast.makeText(SocksHttpMainActivity.this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
						return;
					}
					setTime(millisInput);
					mEditTextInput.setText("");
					
				}
			});
		cmTimer.setOnChronometerTickListener(new OnChronometerTickListener(){
				@Override
				public void onChronometerTick(Chronometer chronometer) {
					long time = SystemClock.elapsedRealtime() - chronometer.getBase();
					int h   = (int)(time /3600000);
					int m = (int)(time - h*3600000)/60000;
					int s= (int)(time - h*3600000- m*60000)/1000 ;
					String t = (h < 10 ? "0"+h: h)+"h:"+(m < 10 ? "0"+m: m)+"m:"+ (s < 10 ? "0"+s: s)+"s";
					chronometer.setText(t);
				}
			});
		cmTimer.setBase(SystemClock.elapsedRealtime());
		cmTimer.setText("00h:00m:00s");
		mButtonStartPause = (Button) findViewById(R.id.start);
		mButtonStartPause.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (mTimerRunning) {
						pauseTimer();
					} else {
						startTimer();
					}
				}
			});
			
		mButtonReset = (Button) findViewById(R.id.reset);
		mButtonReset.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					resetTimer();
				}
			});
		// fix bugs
		
	}
	
    public void chrono(View v) {
        switch(v.getId()) {
            case R.id.btnStart:
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);

                if (!resume) {
                    cmTimer.setBase(SystemClock.elapsedRealtime());
                    cmTimer.start();
                } else {
                    cmTimer.start();
                }
                break;

            case R.id.btnStop:
                btnStart.setEnabled(true);
                btnStop.setEnabled(false);
                cmTimer.stop();
                cmTimer.setText("00h:00m:00s");
                resume = true;
                btnStart.setText("Resume");
                break;

            case R.id.btnReset:
                cmTimer.stop();
                cmTimer.setText("00h:00m:00s");
                resume = false;
                btnStop.setEnabled(false);
                break;
        }}
		
	private void expanded() {
		//set Visible
		cLinearLayout.setVisibility(View.VISIBLE);
		cArrow1.animate().setDuration(500).rotation(0);
		final int widthSpecs = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
		final int heightSpecs = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
		cLinearLayout.measure(widthSpecs, heightSpecs);

		ValueAnimator cAnimator = slideAnimators(0, cLinearLayout.getMeasuredHeight());
		cAnimator.start();
	}


	private ValueAnimator slideAnimators(int start, int end) {

		ValueAnimator animators = ValueAnimator.ofInt(start, end);

		animators.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					//Update Height
					int values = (Integer) valueAnimator.getAnimatedValue();
					ViewGroup.LayoutParams layoutParamsC = cLinearLayout.getLayoutParams();
					layoutParamsC.height = values;
					cLinearLayout.setLayoutParams(layoutParamsC);
				}
			});
		return animators;
	}

	private void collapsing() {
		int finalHeight = cLinearLayout.getHeight();
		cArrow1.animate().setDuration(500).rotation(180);
		ValueAnimator cAnimator = slideAnimators(finalHeight, 0);

		cAnimator.addListener(new Animator.AnimatorListener() {

				@Override
				public void onAnimationStart(Animator p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onAnimationCancel(Animator p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onAnimationRepeat(Animator p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onAnimationEnd(Animator animator) {
					//Height=0, but it set visibility to GONE
					cLinearLayout.setVisibility(View.GONE);
				}

			});
		cAnimator.start();
	}

	private void expand() {
		//set Visible
		mLinearLayout.setVisibility(View.VISIBLE);
		mArrow1.animate().setDuration(500).rotation(0);

		final int widthSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
		final int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
		mLinearLayout.measure(widthSpec, heightSpec);

		ValueAnimator mAnimator = slideAnimator(0, mLinearLayout.getMeasuredHeight());
		mAnimator.start();
	}


	private ValueAnimator slideAnimator(int start, int end) {

		ValueAnimator animator = ValueAnimator.ofInt(start, end);

		animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					//Update Height
					int value = (Integer) valueAnimator.getAnimatedValue();
					ViewGroup.LayoutParams layoutParams = mLinearLayout.getLayoutParams();
					layoutParams.height = value;
					mLinearLayout.setLayoutParams(layoutParams);
				}
			});
		return animator;
	}

	private void collapse() {
		int finalHeight = mLinearLayout.getHeight();
		mArrow1.animate().setDuration(500).rotation(180);
		ValueAnimator mAnimator = slideAnimator(finalHeight, 0);

		mAnimator.addListener(new Animator.AnimatorListener() {

				@Override
				public void onAnimationStart(Animator p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onAnimationCancel(Animator p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onAnimationRepeat(Animator p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onAnimationEnd(Animator animator) {
					//Height=0, but it set visibility to GONE
					mLinearLayout.setVisibility(View.GONE);
				}

			});
		mAnimator.start();
	}
	
	private class TabAdapter extends PagerAdapter
	{

		private List<String> title;
		public TabAdapter(List<String> pageStr)
		{
			title = pageStr;
		}

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return 4;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position)
		{
			int id = 0;
			int[] tabid = new int[]{R.id.mainTab, R.id.logTab,R.id.statsTab,R.id.otherTab};
			id = tabid[position];
			// TODO: Implement this method
			return findViewById(id);
		}


		@Override
		public boolean isViewFromObject(View p1, Object p2)
		{
			// TODO: Implement this method
			return p1 == p2;
		}

		@Override
		public Parcelable saveState()
		{
			// TODO: Implement this method
			return super.saveState();
		}

		@Override
		public CharSequence getPageTitle(int position)
		{
			// TODO: Implement this method
			return title.get(position);
		}


	}
	
	public class DrawerPanel
	implements NavigationView.OnNavigationItemSelectedListener
	{
		private AppCompatActivity mActivity;

        private Intent intent3;
		public DrawerPanel(AppCompatActivity activity) {
			mActivity = activity;
		}
		private static final float END_SCALE = 0.7f;
		private TextView labelView;
		private View contentView;
		private DrawerLayout drawerLayout;
		private ActionBarDrawerToggle toggle;

		public void setDrawer(Toolbar toolbar) {
			NavigationView drawerNavigationView = (NavigationView) mActivity.findViewById(R.id.drawerNavigationView);
			drawerLayout = (DrawerLayout) mActivity.findViewById(R.id.drawerLayoutMain);

			// set drawer
			toggle = new ActionBarDrawerToggle(mActivity,
											   drawerLayout, toolbar, R.string.open, R.string.cancel);

			drawerLayout.setDrawerListener(toggle);

			toggle.syncState();
			////////
			labelView = (TextView) findViewById(R.id.label);
			contentView = findViewById(R.id.content);
			drawerLayout.setDrawerElevation(0);
			drawerLayout.setScrimColor(Color.TRANSPARENT);
			drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
					@Override
					public void onDrawerSlide(View drawerView, float slideOffset) {
						labelView.setVisibility(slideOffset > 0 ? View.VISIBLE : View.GONE);

						// Scale the View based on current slide offset
						final float diffScaledOffset = slideOffset * (1 - END_SCALE);
						final float offsetScale = 1 - diffScaledOffset;
						contentView.setScaleX(offsetScale);
						contentView.setScaleY(offsetScale);

						// Translate the View, accounting for the scaled width
						final float xOffset = drawerView.getWidth() * slideOffset;
						final float xOffsetDiff = contentView.getWidth() * diffScaledOffset / 2;
						final float xTranslation = xOffset - xOffsetDiff;
						contentView.setTranslationX(xTranslation);
					}

					@Override
					public void onDrawerClosed(View drawerView) {
						labelView.setVisibility(View.GONE);
					}
				}
			);

			// set app info
			PackageInfo pinfo = Utils.getAppInfo(mActivity);
			if (pinfo != null) {
				String version_nome = pinfo.versionName;
				int version_code = pinfo.versionCode;
				String header_text = String.format("v. %s (%d)", version_nome, version_code);

				View view = drawerNavigationView.getHeaderView(0);

				TextView app_info_text = view.findViewById(R.id.nav_headerAppVersion);
				app_info_text.setText(header_text);
			}

			// set navigation view
			drawerNavigationView.setNavigationItemSelectedListener(this);
		}
		
		public ActionBarDrawerToggle getToogle() {
			return toggle;
		}

		public DrawerLayout getDrawerLayout() {
			return drawerLayout;
		}
		
		@Override
		public boolean onNavigationItemSelected(@NonNull MenuItem item) {
			int id = item.getItemId();

			switch(id)
			{
				case R.id.PayGen:
					
					
					if (SkStatus.isTunnelActive()) {
						Toast.makeText(SocksHttpMainActivity.this, "Running service,stop it first",Toast.LENGTH_SHORT).show();
						
					}
					else {
						if (customPayloadSwitch.isChecked()) {
							showPayloadGenerator();
						}else{
							Toast.makeText(SocksHttpMainActivity.this, "Please enable Custom Payload.",Toast.LENGTH_SHORT).show();

						}
					}
					drawerLayout.closeDrawers();
					break;
				case R.id.miPhoneConfg:
					PackageInfo app_info = Utils.getAppInfo(mActivity);
					if (app_info != null) {
						String aparelho_marca = Build.BRAND.toUpperCase();

						if (aparelho_marca.equals("OPPO") || aparelho_marca.equals("HUAWEY")) {
							Toast.makeText(mActivity, R.string.error_no_supported, Toast.LENGTH_SHORT)
								.show();
						}
						else {
							try {
								Intent in = new Intent(Intent.ACTION_MAIN);
								in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								in.setClassName("com.android.settings", "com.android.settings.RadioInfo");
								mActivity.startActivity(in);
							} catch(Exception e) {
								Toast.makeText(mActivity, R.string.error_no_supported, Toast.LENGTH_SHORT)
									.show();
							}
						}
					}
					drawerLayout.closeDrawers();
					break;
                
					
				case R.id.miSettings:
					Intent intent = new Intent(mActivity, ConfigGeralActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					mActivity.startActivity(intent);
					break;

				case R.id.miSettingsSSH:
					Intent intent2 = new Intent(mActivity, ConfigGeralActivity.class);
					intent2.setAction(ConfigGeralActivity.OPEN_SETTINGS_SSH);
					intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					mActivity.startActivity(intent2);
					break;
				
				
				case R.id.menu_host_checker:
					startActivity(new Intent(SocksHttpMainActivity.this, HostChecker.class));
					break;
                    
                    
				case R.id.miSendFeedback:
					if (false && Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
						try {
							GoogleFeedbackUtils.bindFeedback(mActivity);
						} catch (Exception e) {
							Toast.makeText(mActivity, "Não disponível em seu aparelho", Toast.LENGTH_SHORT)
								.show();
							SkStatus.logDebug("Error: " + e.getMessage());
						}
					}
					else {
						Intent email = new Intent(Intent.ACTION_SEND);  
						email.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

						email.putExtra(Intent.EXTRA_EMAIL, new String[]{"mem925899@gmail.com"});  
						email.putExtra(Intent.EXTRA_SUBJECT, "JAsocks|Tunnel - " + mActivity.getString(R.string.feedback));  
						email.setType("message/rfc822");  

						mActivity.startActivity(Intent.createChooser(email, "Choose an Email client:"));
					}
					drawerLayout.closeDrawers();
					break;

			}

			return true;
		}

	}
	
	
	class JsonTask extends AsyncTask<String, String, String> {

		protected void onPreExecute() {
			super.onPreExecute();

		}

		protected String doInBackground(String... params) {


			HttpURLConnection connection = null;
			BufferedReader reader = null;

			try {
				URL url = new URL(params[0]);
				connection = (HttpURLConnection) url.openConnection();
				connection.connect();


				InputStream stream = connection.getInputStream();

				reader = new BufferedReader(new InputStreamReader(stream));

				StringBuffer buffer = new StringBuffer();
				String line = "";

				while ((line = reader.readLine()) != null) {
					buffer.append(line+"\n");
					Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-) 

				}

				return buffer.toString();


			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (connection != null) {
					connection.disconnect();
				}
				try {
					if (reader != null) {
						reader.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			MsgAdmin.setText(result);
		}
	}
	private void Toast(String msg)
    {
		Toast.makeText(SocksHttpMainActivity.this, msg,Toast.LENGTH_SHORT).show();
    }
	
	
	private void progressBar() {
		progressStatus = 0;
		new Thread(new Runnable() {
				@Override
				public void run() {
					while(progressStatus < 100){
						// Update the progress status
						progressStatus +=1;

						// Try to sleep the thread for 20 milliseconds
						try{
							Thread.sleep(20);
						}catch(InterruptedException e){
							e.printStackTrace();
						}
						handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    progressBar.setProgress(progressStatus);
                                    progress_status.setText(progressStatus+"");
                                }
                            });
					}
				}
			}).start(); // Start the operation
	}
	private void running(){
		boolean isRunning = SkStatus.isTunnelActive();
		if (SkStatus.isTunnelActive()) {
			customPayloadSwitch.setEnabled(!isRunning);
			ReconnectSwitch.setEnabled(!isRunning);
			proxyText.setEnabled(!isRunning);
			payloadEdit.setEnabled(!isRunning);
			metodoConexaoRadio.setEnabled(!isRunning);
			graphClose.setVisibility(0);
			ConnectionClose.setVisibility(8);
			mTextViewCountDown.setVisibility(8);
			starterButton.setEnabled(!isRunning);
			
			}
	}
	
	private void updateReconnect()
	{
		if (ReconnectSwitch.isChecked()){
			AutoOn.setVisibility(0);
			mTextViewCountDown.setVisibility(0);
		}
		else
		{
			AutoOn.setVisibility(8);
			mTextViewCountDown.setVisibility(8);
		}
		String input = mEditTextInput.getText().toString();
		if (input.length() == 0) {
			return;
		}
		long millisInput = Long.parseLong(input) * 1000;
		if (millisInput == 0) {
			return;
		}
		setTime(millisInput);
		mEditTextInput.setText("");


		if (showGraph.isChecked()) {
			showGraph.setText(R.string.hide);
			showGraph.setChecked(true);
			GraphView.setVisibility(0);

		} else {
		//	graph.stop();
			showGraph.setText(R.string.show);
			showGraph.setChecked(false);
			GraphView.setVisibility(8);
			}
		}
	
	
	private void doUpdateLayout() {
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		boolean isRunning = SkStatus.isTunnelActive();
		int tunnelType = prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
		
		setStarterButton(starterButton, this);
		setPayloadSwitch(tunnelType, !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true));

		String proxyStr = getText(R.string.no_value).toString();

		
		
		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			proxyStr = "☆☆☆☆☆☆☆☆☆☆";
			proxyInputLayout.setEnabled(false);
		}
		else {
			String proxy = mConfig.getPrivString(Settings.PROXY_IP_KEY);

			if (proxy != null && !proxy.isEmpty())
				proxyStr = String.format("%s:%s", proxy, mConfig.getPrivString(Settings.PROXY_PORTA_KEY));
			proxyInputLayout.setEnabled(!isRunning);
		} 

		proxyText.setText(proxyStr);

		
		switch (tunnelType) {
			case Settings.bTUNNEL_TYPE_SSH_DIRECT:
				((AppCompatRadioButton) findViewById(R.id.activity_mainSSHDirectRadioButton))
					.setChecked(true);
				break;

			case Settings.bTUNNEL_TYPE_SSH_PROXY:
				((AppCompatRadioButton) findViewById(R.id.activity_mainSSHProxyRadioButton))
					.setChecked(true);
				break;
			/*case Settings.bTUNNEL_TYPE_SSL_PROXY:
				((AppCompatRadioButton) findViewById(R.id.activity_mainSSLProxyRadioButton))
					.setChecked(true);
				break;*/
		}

		int msgVisibility = View.GONE;
		int loginVisibility = View.GONE;
		String msgText = "";
		boolean enabled_radio = !isRunning;

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			
			if (prefs.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				loginVisibility = View.VISIBLE;
				inputPwUser.setText(mConfig.getPrivString(Settings.USUARIO_KEY));
				inputPwPass.setText(mConfig.getPrivString(Settings.SENHA_KEY));
				inputPwUser.setEnabled(!isRunning);
				inputPwPass.setEnabled(!isRunning);
				inputPwShowPass.setEnabled(!isRunning);
			}
			
			String msg = mConfig.getPrivString(Settings.CONFIG_MENSAGEM_KEY);
			if (!msg.isEmpty()) {
				msgText = msg.replace("\n", "<br/>");
				msgVisibility = View.VISIBLE;
			}
			
			if (mConfig.getPrivString(Settings.PROXY_IP_KEY).isEmpty() ||
					mConfig.getPrivString(Settings.PROXY_PORTA_KEY).isEmpty()) {
				enabled_radio = false;
			}
		}

		loginLayout.setVisibility(loginVisibility);
		configMsgText.setText(msgText.isEmpty() ? "" : Html.fromHtml(msgText));
		configMsgLayout.setVisibility(msgVisibility);
		Viewgone.setVisibility(msgVisibility);
		//ViewGone.setVisibility(msgVisibility);
		// desativa/ativa radio group
		for (int i = 0; i < metodoConexaoRadio.getChildCount(); i++) {
			metodoConexaoRadio.getChildAt(i).setEnabled(enabled_radio);
		}
		}
	
	private synchronized void doSaveData() {
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		SharedPreferences.Editor edit = prefs.edit();

		if (mainLayout != null && !isFinishing())
			mainLayout.requestFocus();
		
		if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			if (payloadEdit != null && !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
				edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payloadEdit.getText().toString());
			}
		}
		else {
			if (prefs.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				edit.putString(Settings.USUARIO_KEY, inputPwUser.getEditableText().toString());
				edit.putString(Settings.SENHA_KEY, inputPwPass.getEditableText().toString());
			}
		}
		edit.apply();
	}


	/**
	 * Tunnel SSH
	 */
	 
	 
	public void doRestart() {
		Intent mStartActivity = new Intent(SocksHttpMainActivity.this, LauncherActivity.class);
		int mPendingIntentId = 123456;
		PendingIntent mPendingIntent = PendingIntent.getActivity(SocksHttpMainActivity.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
		AlarmManager mgr = (AlarmManager) SocksHttpMainActivity.this.getSystemService(Context.ALARM_SERVICE);
		mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
		System.exit(0);
	}
	 
	 
	private void pauseTimer() {
		if(mCountDownTimer != null){
			mCountDownTimer.cancel();
		}
		mTimerRunning = false;
		updateWatchInterface();
	}
	private void resetTimer() {
		mTimeLeftInMillis = mStartTimeInMillis;
		updateCountDownText();
		updateWatchInterface();
	}

	private void updateWatchInterface() {
		if (mTimerRunning) {
			mEditTextInput.setVisibility(View.INVISIBLE);
			mButtonReset.setVisibility(View.INVISIBLE);
			mButtonStartPause.setText("Pause");
		} else {
			mEditTextInput.setVisibility(View.VISIBLE);
			mButtonStartPause.setText("Start");
			if (mTimeLeftInMillis < 1000) {
				mButtonStartPause.setVisibility(View.INVISIBLE);
			} else {
				mButtonStartPause.setVisibility(View.VISIBLE);
			}
			if (mTimeLeftInMillis < mStartTimeInMillis) {
				mButtonReset.setVisibility(View.VISIBLE);
			} else {
				mButtonReset.setVisibility(View.INVISIBLE);
			}
		}
	}


	private void updateCountDownText() {
		int hours = (int) (mTimeLeftInMillis / 1000) / 3600;
		int minutes = (int) ((mTimeLeftInMillis / 1000) % 3600) / 60;
		int seconds = (int) (mTimeLeftInMillis / 1000) % 60;
		String timeLeftFormatted;
		if (hours > 0) {
			timeLeftFormatted = String.format(Locale.getDefault(),
											  "%d:%02d:%02ds", hours, minutes, seconds);
		} else {
			timeLeftFormatted = String.format(Locale.getDefault(),
											  "%02ds", seconds);
		}
		mTextViewCountDown.setText(timeLeftFormatted);
	}

	private void setTime(long milliseconds) {
		mStartTimeInMillis = milliseconds;
		resetTimer();

	}

	private void startTimer() {
		mEndTime = System.currentTimeMillis() + mTimeLeftInMillis;
		mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {


			@Override
			public void onTick(long millisUntilFinished) {
				mTimeLeftInMillis = millisUntilFinished;
				updateCountDownText();
			}
			@Override
			public void onFinish() {
				mTimerRunning = false;
				updateWatchInterface();
				pauseTimer();
				resetTimer();
				startTimer();
		
				Intent reconTunnel = new Intent(SocksHttpService.TUNNEL_SSH_RESTART_SERVICE);
				LocalBroadcastManager.getInstance(SocksHttpMainActivity.this)
					.sendBroadcast(reconTunnel);

			}
		}.start();
		mTimerRunning = true;
		updateWatchInterface();
	}
	public static String getFileSize(long size) { 
		if (size <= 0)
			return "0";
		final String[] units = new String[] { "B", "KB", "MB", "GB", "TB" };
		int digitGroups = (int) (Math.log10(size) / Math.log10(1024)); 
		return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
	
	}
	
	
	private static String render_bandwidth(long bw) {
        String postfix;
        float div;
        Object[] objArr;
        float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            postfix = "TB";
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            postfix = "GB";
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            postfix = "MB";
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            postfix = "KB";
            div = 1024.0f;
        } else {
            objArr = new Object[1];
            objArr[0] = Float.valueOf(bwf);
            return String.format("%.0f", objArr);
        }
        objArr = new Object[1];
        objArr[0] = Float.valueOf(bwf / div);
        objArr[1] = postfix;
        return String.format("%.2f %s", objArr);
    }
	
	private String humanReadable(long size) {
		long limit = 10 * 1024;
		long limit2 = limit * 2 - 1;
		String negative = "";
		if(size < 0) {
			negative = "-";
			size = Math.abs(size);
		}

		if(size < limit) {
			return String.format("%s%s bytes", negative, size);
		} else {
			size = Math.round((double) size / 1024);
			if (size < limit2) {
				return String.format("%s%s kB", negative, size);
			} else {
				size = Math.round((double)size / 1024);
				if (size < limit2) {
					return String.format("%s%s MB", negative, size);
				} else {
					size = Math.round((double)size / 1024);
					if (size < limit2) {
						return String.format("%s%s GB", negative, size);
					} else {
						size = Math.round((double)size / 1024);
                        return String.format("%s%s TB", negative, size);
					}
				}
			}
		}
	}
	
	
	private String getLog()
	{
		StringBuilder str = new StringBuilder();
		for (int i = 0; i < mLogAdapter.getItemCount(); i++) {
			str.append(mLogAdapter.getItem(i) +"\n");
		}
		return str.toString();
	}
	
	private ITrafficSpeedListener mStreamSpeedListener = new ITrafficSpeedListener() {

        @Override
        public void onTrafficSpeedMeasured(final double upStream, final double downStream) {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						String upStreamSpeed = Utils.parseSpeed(upStream, SHOW_SPEED_IN_BITS);
						String downStreamSpeed = Utils.parseSpeed(downStream, SHOW_SPEED_IN_BITS);
						SpeedBytes_In.setText("Download Speed :↓" + downStreamSpeed);
						SpeedBytes_Out.setText(upStreamSpeed +"↑: Upload Speed");
					}
				});
        }
    };
	
	
	public void checkNettype() {
		ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (activeNetwork != null) { // connected to the internet
			if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
				wifi_mobile.setText(activeNetwork.getTypeName());
			} else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
				wifi_mobile.setText(activeNetwork.getTypeName());
			
			}
		}
	}
	
	
	
	private void updateHeaderCallback() {
		new JsonTask().execute(MSGadmn);
		new FetchColumnAsync(this).execute(jasockstunnel);
		LocalIP.setText("" + GetLocalIPAddress(this));
		checkNettype();
		if (!TunnelUtils.isNetworkOnline(this)) {
			ViewMessage.setVisibility(8);
		}
		else
		{
			ViewMessage.setVisibility(0);
		
		}
	}
	
	private void getPublicIP() {
		final ArrayList<String> urls=new ArrayList<String>(); //to read each line

        new Thread(new Runnable(){
				public void run(){
					//TextView t; //to show the result, please declare and find it inside onCreate()

					try {
						// Create a URL for the desired page
						URL url = new URL("https://api.ipify.org/"); //My text file location
						//First open the connection
						HttpURLConnection conn=(HttpURLConnection) url.openConnection();
						conn.setConnectTimeout(60000); // timing out in a minute

						BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

						//t=(TextView)findViewById(R.id.TextView1); // ideally do this in onCreate()
						String str;
						while ((str = in.readLine()) != null) {
							urls.add(str);
						}
						in.close();
					} catch (Exception e) {
						Log.d("MyTag",e.toString());
					}

					//since we are in background thread, to post results we have to go back to ui thread. do the following for that

					SocksHttpMainActivity.this.runOnUiThread(new Runnable(){
							public void run(){
								try {
									ExternalIP.setText("" + urls.get(0));
									//	Toast.makeText(SocksHttpMainActivity.this, "Public IP:"+urls.get(0), Toast.LENGTH_SHORT).show();
								}
								catch (Exception e){
								///	Toast.makeText(SocksHttpMainActivity.this, "", Toast.LENGTH_SHORT).show();
								}
							}
						});

				}
			}).start();

    }
	
	public static String GetLocalIPAddress(Context context) {
        NetworkInfo info = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (info != null && info.isConnected()) {
            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {//Currently use 2G/3G/4G network
                try {
                    //Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();
                    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                        NetworkInterface intf = en.nextElement();
                        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                            InetAddress inetAddress = enumIpAddr.nextElement();
                            if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                return inetAddress.getHostAddress();
                            }
                        }
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                }

            } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {//Currently using wireless network
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String ipAddress = intIP2StringIP(wifiInfo.getIpAddress());//Get IPV4 address
                return ipAddress;
            }
        } else {
            //No network connection currently, please open the network in the settings
        }
        return null;
    }
	
	public static String intIP2StringIP(int ip) {
        return (ip & 0xFF) + "." +
			((ip >> 8) & 0xFF) + "." +
			((ip >> 16) & 0xFF) + "." +
			(ip >> 24 & 0xFF);
    }
	
	public void liveData()
	{

        dataUpdate = new Thread(new Runnable() {
				@Override
				public void run()
				{

					while (!dataUpdate.getName().equals("stopped"))
					{

						vHandler.post(new Runnable() {

								//private static final long xup = 0;

								@Override
								public void run()

								{
								
								}
							});

						try
						{
							Thread.sleep(1000);
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
						//  progressStatus--;
					}

				}
			});

        dataUpdate.setName("started");
        dataUpdate.start();
    }
	
	

	public void startOrStopTunnel(Activity activity) {
		if (SkStatus.isTunnelActive()) {
			TunnelManagerHelper.stopSocksHttp(activity);
			Toast.makeText(SocksHttpMainActivity.this, "Service stopped",Toast.LENGTH_SHORT).show();
			Animation close = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
			ConnectionClose.startAnimation(close);
			ConnectionClose.setVisibility(0);
			graphClose.setVisibility(8);
			dataThread = new Thread(new MyThreadClass());
			dataThread.setName("stopDataGraph");
			cmTimer.stop();
			cmTimer.setText("00h:00m:00s");
			resume = false;
			if(ReconnectSwitch.isChecked()){
				pauseTimer();
				resetTimer();
				}
			}
      else {
	
			if (!TunnelUtils.isNetworkOnline(this)) {
				SkStatus.updateStateString("USER_VPN_PASSWORD_CANCELLED", "", R.string.state_user_vpn_password_cancelled,
										   ConnectionStatus.LEVEL_NOTCONNECTED);
			}
			else{
			  
			if (!resume) {
				cmTimer.setBase(SystemClock.elapsedRealtime());
				cmTimer.start();
			} else {
				cmTimer.start();
			}
			}
			if(ReconnectSwitch.isChecked()){
				if (!TunnelUtils.isNetworkOnline(this)) {
				 SkStatus.updateStateString("USER_VPN_PASSWORD_CANCELLED", "", R.string.state_user_vpn_password_cancelled,
				 ConnectionStatus.LEVEL_NOTCONNECTED);
				 Toast.makeText(this, R.string.error_internet_off,
				 Toast.LENGTH_SHORT).show();
			}
			else{
				startTimer();
				graphClose.setVisibility(0);
				ConnectionClose.setVisibility(8);
			}
			}
		  
		    ExternalIP.setText("Checking...");
			btnStart.setEnabled(true);
			dataThread = new Thread(new MyThreadClass());
			dataThread.setName("showDataGraph");
			dataThread.start();
			LinearLayout Graphs = (LinearLayout)findViewById(R.id.graphView);
			Animation aniFade = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
			Graphs.startAnimation(aniFade);
			graphClose.setVisibility(0);
			ConnectionClose.setVisibility(8);
			
		  if (mConfig.getPrivString(Settings.SERVIDOR_KEY).isEmpty() || mConfig.getPrivString(Settings.SERVIDOR_PORTA_KEY).isEmpty()) {
			  SkStatus.updateStateString("USER_VPN_PASSWORD_CANCELLED", "", R.string.state_user_vpn_password_cancelled,
										 ConnectionStatus.LEVEL_NOTCONNECTED);
			  Toast.makeText(SocksHttpMainActivity.this, "Set Up First Your SSH SETTINGS",
							 Toast.LENGTH_SHORT).show();
			  cmTimer.setEnabled(false);
			  cmTimer.setText("00h:00m:00s");
			  cmTimer.stop();
			  pauseTimer();
			  Intent intent2 = new Intent(activity, ConfigGeralActivity.class);
			  intent2.setAction(ConfigGeralActivity.OPEN_SETTINGS_SSH);
			  intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			  activity.startActivity(intent2);
			}
			
			
		  if (mConfig.getPrivString(Settings.USUARIO_KEY).isEmpty() || (mConfig.getPrivString(Settings.SENHA_KEY).isEmpty() &&
			  (mTransientAuthPW == null || mTransientAuthPW.isEmpty()))) {
			  SkStatus.updateStateString("USER_VPN_PASSWORD", "", R.string.state_user_vpn_password,
										 ConnectionStatus.LEVEL_WAITING_FOR_USER_INPUT);
			  cmTimer.setEnabled(false);
			  cmTimer.setText("00h:00m:00s");
			  cmTimer.stop();
			  pauseTimer();
	       }
			Settings config = new Settings(activity);
			if (config.getPrefsPrivate()
					.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				if (inputPwUser.getText().toString().isEmpty() || 
						inputPwPass.getText().toString().isEmpty()) {
					Toast.makeText(this, R.string.error_userpass_empty, Toast.LENGTH_SHORT)
						.show();
						
					return;
				}
			}
			
			Intent intent = new Intent(activity, LaunchVpn.class);
			intent.setAction(Intent.ACTION_MAIN);
			activity.startActivity(intent);
		}
	}

	private void setPayloadSwitch(int tunnelType, boolean isCustomPayload) {
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		boolean isRunning = SkStatus.isTunnelActive();

		customPayloadSwitch.setChecked(isCustomPayload);

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			payloadEdit.setEnabled(false);
			
			if (mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY).isEmpty()) {
				customPayloadSwitch.setEnabled(false);
		        ReconnectSwitch.setEnabled(false);
				
			}
			else {
				customPayloadSwitch.setEnabled(!isRunning);
			    ReconnectSwitch.setEnabled(!isRunning);
				
			}
			
			if (!isCustomPayload && tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY)
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
				
			else
				payloadEdit.setText("☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆");
				PayloadLock.setVisibility(8);
			    customPayloadSwitch.setEnabled(true);
			    customPayloadSwitch.setEnabled(!isRunning);
			    
		}
		else {
			PayloadLock.setVisibility(0);
			customPayloadSwitch.setEnabled(!isRunning);
			ReconnectSwitch.setEnabled(!isRunning);

			if (isCustomPayload) {
				payloadEdit.setText(mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY));
				proxyText.setText(mConfig.getPrivString(Settings.PROXY_IP_KEY)+":"+(mConfig.getPrivString(Settings.PROXY_PORTA_KEY)));
				proxyText.setEnabled(!isRunning);
				proxyInputLayout.setEnabled(!isRunning);
				payloadEdit.setEnabled(!isRunning);
				
			}
			else if (tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY) {
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
				proxyText.setText(Settings.PROXY_REMOTE);
				payloadEdit.setEnabled(false);
				proxyText.setEnabled(false);
				proxyInputLayout.setEnabled(false);
			
			}
		}

		if (isCustomPayload || tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY) {
			payloadLayout.setVisibility(View.VISIBLE);
			ViewGone.setVisibility(View.VISIBLE);
			
		}
		else {
			payloadLayout.setVisibility(View.GONE);
			ViewGone.setVisibility(View.GONE);
		}
	}

	public void setStarterButton(Button starterButton, Activity activity) {
		String state = SkStatus.getLastState();
		boolean isRunning = SkStatus.isTunnelActive();

		if (starterButton != null) {
			int resId;
			
			SharedPreferences prefsPrivate = new Settings(activity).getPrefsPrivate();

			if (ConfigParser.isValidadeExpirou(prefsPrivate
					.getLong(Settings.CONFIG_VALIDADE_KEY, 0))) {
				resId = R.string.expired;
				starterButton.setEnabled(false);

				if (isRunning) {
					startOrStopTunnel(activity);
					
				}
			}
			else if (prefsPrivate.getBoolean(Settings.BLOQUEAR_ROOT_KEY, false) &&
					ConfigParser.isDeviceRooted(activity)) {
			   resId = R.string.blocked;
			   starterButton.setEnabled(false);
			   
			   Toast.makeText(activity, R.string.error_root_detected, Toast.LENGTH_SHORT)
					.show();

			   if (isRunning) {
				   startOrStopTunnel(activity);
			   }
			}
			else if (SkStatus.SSH_INICIANDO.equals(state)) {
				resId = R.string.stop;
				starterButton.setEnabled(false);
				
			}
			
			else {
				resId = isRunning ? R.string.stop : R.string.start;
				starterButton.setEnabled(true);
				customPayloadSwitch.setEnabled(!isRunning);
				ReconnectSwitch.setEnabled(!isRunning);
				proxyText.setEnabled(!isRunning);
				payloadEdit.setEnabled(!isRunning);
				metodoConexaoRadio.setEnabled(!isRunning);
			}

			starterButton.setText(resId);
		}
	}
	final class MyThreadClass implements Runnable{
        @Override
        public void run(){
            int i = 0;
            synchronized (this)
			{
                while (dataThread.getName() == "showDataGraph")
				{
                    //  Log.e("insidebroadcast", Integer.toString(service_id) + " " + Integer.toString(i));
                    getData2();
                    try
					{
                        wait(1000);
                        i++;
                    }
					catch (InterruptedException e)
					{
						// sshMsg(e.getMessage());
                    }

                }
				// stopSelf(service_id);
            }

        }
    }
	
	public void getData2(){
        List<Long> allData;
        allData = RetrieveData.findData();
		long mDownload = ArmorGraph.download;
		long mUpload = ArmorGraph.upload;
		mDownload = allData.get(0);
        mUpload = allData.get(1);
		storedData2(mUpload,mDownload);
    }

	public void storedData2(Long mUpload,Long mDownload){
        StoredData.downloadSpeed = mDownload;
        StoredData.uploadSpeed = mUpload;
        if (StoredData.isSetData){
            StoredData.downloadList.remove(0);
            StoredData.uploadList.remove(0);
            StoredData.downloadList.add(mDownload);
            StoredData.uploadList.add(mUpload);
        }
    }
	
	@Override
	public void onValueFetched(String value){
		
		MsG.setText(value);
		getPublicIP();
		
	}
	

	@Override
    public void onPostCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);
        if (mDrawerPanel.getToogle() != null)
			mDrawerPanel.getToogle().syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (mDrawerPanel.getToogle() != null)
			mDrawerPanel.getToogle().onConfigurationChanged(newConfig);
    }
	
	private boolean isMostrarSenha = false;
	
	@Override
	public void onClick(View p1)
	{
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		switch (p1.getId()) {
			case R.id.activity_starterButtonMain:
				doSaveData();
				startOrStopTunnel(this);
			
				break;
				
			case R.id.activity_mainInputProxyLayout:
				if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					doSaveData();

					DialogFragment fragProxy = new ProxyRemoteDialogFragment();
					fragProxy.show(getSupportFragmentManager(), "proxyDialog");
				}
				break;

			case R.id.activity_mainAutorText:
				String url = "http://t.me/SlipkProjects";
				Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(Intent.createChooser(intent, getText(R.string.open_with)));
				break;
				
			case R.id.activity_mainInputShowPassImageButton:
				isMostrarSenha = !isMostrarSenha;
				if (isMostrarSenha) {
					inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
					inputPwShowPass.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_visibility_black_24dp));
				}
				else {
					inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
					inputPwShowPass.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_visibility_off_black_24dp));
				}
			break;
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup p1, int p2)
	{
		SharedPreferences.Editor edit = mConfig.getPrefsPrivate().edit();

		switch (p1.getCheckedRadioButtonId()) {
			case R.id.activity_mainSSHDirectRadioButton:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
				proxyInputLayout.setVisibility(View.GONE);
				break;

			case R.id.activity_mainSSHProxyRadioButton:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY);
				proxyInputLayout.setVisibility(View.VISIBLE);
				break;
			/*case R.id.activity_mainSSLProxyRadioButton:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_PROXY);
				proxyInputLayout.setVisibility(View.GONE);
				break;*/
		}

		edit.apply();

		doSaveData();
		doUpdateLayout();
	}

	@Override
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		SharedPreferences.Editor edit = prefs.edit();

		switch (p1.getId()) {
			case R.id.activity_mainCustomPayloadSwitch:
				edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, !p2);
				setPayloadSwitch(prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT), p2);
				break;
		}

		edit.apply();

		doSaveData();
	}
	
	protected void showBoasVindas() {
		new AlertDialog.Builder(this)
            . setTitle(R.string.attention)
            . setMessage(R.string.first_start_msg)
			. setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface di, int p) {
					// ok
				}
			})
			. setCancelable(false)
            . show();
	}
	
	protected void showLicenses() {
		LayoutInflater li = LayoutInflater.from(this);
		View view = li.inflate(R.layout.fragment_dialog_licenses, null); 

		try
		{
			String aboutText = Utils.readFromAssets(this,"LICENSE");
			aboutText = aboutText.replace("\n","<br/>");

			((TextView) view.findViewById(R.id.fragment_dialog_licensesAllTextView))
				.setText(Html.fromHtml(aboutText));
		}
		catch (Exception e){}

		new AlertDialog.Builder(this)
            .setTitle("Licenses")
            .setView(view)
            .show();
	}

	public void showAgradecimentos() {
		try
		{
			String aboutText = Utils.readFromAssets(this,"AGRADECIMENTOS");
			aboutText = aboutText.replace("\n","<br/>");

			((TextView) findViewById(R.id.activity_aboutAgradecimentosTextView))
				.setText(Html.fromHtml(aboutText));
		}
		catch (Exception e){}
	}
	
    
	@Override
	public void updateState(final String state, String msg, int localizedResId, final ConnectionStatus level, Intent intent)
	{
		
		mHandler.post(new Runnable() {
				@Override
				public void run() {
					doUpdateLayout();
					updateReconnect();
				
						if (level.equals(ConnectionStatus.LEVEL_CONNECTED)) {
							graph.start();
							Toast.makeText(SocksHttpMainActivity.this, "JAsocks|Tunnel is in Service ",Toast.LENGTH_SHORT).show();
						//	Toast.makeText(SocksHttpMainActivity.this, "Connected",Toast.LENGTH_SHORT).show();
							status.setText(R.string.connected);
							progress_status.setText(R.string.connected);
							ProgressView.setVisibility(8);
							statistics.setVisibility(0);
							if(showGraph.isChecked()){
								graph.start();
							}
							
							
						}
						else
						if (level.equals(ConnectionStatus.LEVEL_NOTCONNECTED)) {
							status.setText(R.string.disconnected);
							progress_status.setText(R.string.disconnected);
							ProgressView.setVisibility(8);
							LogViewClear();
					
						}
						else
						if (level.equals(ConnectionStatus.LEVEL_CONNECTING_SERVER_REPLIED)) {
							status.setText(R.string.authenticating);
						}
						else
						if (level.equals(ConnectionStatus.LEVEL_CONNECTING_NO_SERVER_REPLY_YET)) {
							status.setText(R.string.connecting);
							progress_status.setText(R.string.connecting);
							ProgressView.setVisibility(0);
							starterButton.setText(R.string.stop);
							starterButton.setEnabled(true);
							progressBar();
							//if (mConfig.getAutoClearLog())
								//SkStatus.clearLog();
						
						}
						else
						if (level.equals(ConnectionStatus.LEVEL_AUTH_FAILED)) {
							status.setText(R.string.authfailed);
							progress_status.setText(R.string.authfailed);
						}
						else
						if (level.equals(ConnectionStatus.UNKNOWN_LEVEL)) {
							status.setText(R.string.disconnecting);
							progress_status.setText(R.string.disconnecting);
							ProgressView.setVisibility(8);
							graph.stop();
							statistics.setVisibility(8);
							if(showGraph.isChecked()){
								graph.stop();
							}
							
								
							
						}
						else
						if (level.equals(ConnectionStatus.LEVEL_RECONNECTING)) {
							status.setText(R.string.reconnecting);
							progress_status.setText(R.string.reconnecting);
								if (mConfig.getAutoClearLog()){
									SkStatus.clearLog();
								mLogAdapter.clearLog();
							}
							else
							{
								
							}
						}
						else
						if (level.equals(ConnectionStatus.LEVEL_NONETWORK)) {
							status.setText(R.string.nonetwork);
							progress_status.setText(R.string.nonetwork);
						}
					
					
				}
			});
			
			
		/*switch (state) {
			case SkStatus.SSH_CONECTADO:
				Toast.makeText(SocksHttpMainActivity.this, "Connected",Toast.LENGTH_SHORT).show();
				break;
				}*/
		/*switch (state) {
			case SkStatus.SSH_CONECTADO:
				// carrega ads banner
				
				
				if (adsBannerView != null && TunnelUtils.isNetworkOnline(SocksHttpMainActivity.this)) {
					adsBannerView.setAdListener(new AdListener() {
							@Override
							public void onAdLoaded() {
								if (adsBannerView != null && !isFinishing()) {
									adsBannerView.setVisibility(View.VISIBLE);
								}
							}
						});
					adsBannerView.postDelayed(new Runnable() {
							@Override
							public void run() {
								// carrega ads interestitial
								AdsManager.newInstance(getApplicationContext())
									.loadAdsInterstitial();
								// ads banner
								if (adsBannerView != null && !isFinishing()) {
									adsBannerView.loadAd(new AdRequest.Builder()
														 .build());
								}
							}
						}, 5000);
				}
				break;
		}*/
	}
	


	/**
	 * Recebe locais Broadcast
	 */

	private BroadcastReceiver mActivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null)
                return;

            if (action.equals(UPDATE_VIEWS) && !isFinishing()) {
				doUpdateLayout();
			}
			else if (action.equals(OPEN_LOGS)) {
				
			}
        }
    };
	
	

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
		
		
		
		if (Vpager.getCurrentItem()==0){
			menu.findItem(R.id.importExport).setVisible(true);
			menu.findItem(R.id.log_copy).setVisible(false);
			menu.findItem(R.id.clearlog).setVisible(false);
			menu.findItem(R.id.miSettings).setVisible(true);
		} else if(Vpager.getCurrentItem()==1){
			menu.findItem(R.id.log_copy).setVisible(true);
		//	menu.findItem(R.id.share_log).setVisible(true);
			menu.findItem(R.id.importExport).setVisible(false);
			menu.findItem(R.id.clearlog).setVisible(true);
			menu.findItem(R.id.miSettings).setVisible(false);
		} else if(Vpager.getCurrentItem()==2){
			menu.findItem(R.id.log_copy).setVisible(false);
			menu.findItem(R.id.importExport).setVisible(false);
			menu.findItem(R.id.clearlog).setVisible(false);
			menu.findItem(R.id.miSettings).setVisible(false);
			
	     } else if(Vpager.getCurrentItem()==3){
		    menu.findItem(R.id.log_copy).setVisible(false);
		    menu.findItem(R.id.importExport).setVisible(false);
		    menu.findItem(R.id.clearlog).setVisible(false);
		    menu.findItem(R.id.miSettings).setVisible(false);
	}
		
		
        return super.onCreateOptionsMenu(menu);
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (mDrawerPanel.getToogle() != null && mDrawerPanel.getToogle().onOptionsItemSelected(item)) {
            return true;
        }

		// Menu Itens
		switch (item.getItemId()) {
			
			case R.id.miLimparConfig:
				if (!SkStatus.isTunnelActive()) {
					DialogFragment dialog = new ClearConfigDialogFragment();
					dialog.show(getSupportFragmentManager(), "alertClearConf");
				} else {
					Toast.makeText(this, R.string.error_tunnel_service_execution, Toast.LENGTH_SHORT)
						.show();
				}
				break;
				
			case R.id.restart_app:
				doRestart();
				break;

		
			case R.id.miSettings:
				Intent intentSettings = new Intent(this, ConfigGeralActivity.class);
				startActivity(intentSettings);
				
				break;

			case R.id.miSettingImportar:
				if (SkStatus.isTunnelActive()) {
					Toast.makeText(this, R.string.error_tunnel_service_execution,
						Toast.LENGTH_SHORT).show();
				}
				else {
					Intent intentImport = new Intent(this, ConfigImportFileActivity.class);
					startActivity(intentImport);
				}
				break;

			case R.id.miSettingExportar:
				SharedPreferences prefs = mConfig.getPrefsPrivate();
				
				if (SkStatus.isTunnelActive()) {
					Toast.makeText(this, R.string.error_tunnel_service_execution,
						Toast.LENGTH_SHORT).show();
				}
				else if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					Toast.makeText(this, R.string.error_settings_blocked,
						Toast.LENGTH_SHORT).show();
				}
				else {
					Intent intentExport = new Intent(this, ConfigExportFileActivity.class);
					startActivity(intentExport);
				}
				break;
				
				
			
				// logs opções
			case R.id.clearlog:
				SkStatus.clearLog();
			//	SkStatus.logInfo("Log Cleareds");
				break;
				
			case R.id.log_copy:
				int sdk = android.os.Build.VERSION.SDK_INT;
				if(sdk < android.os.Build.VERSION_CODES.HONEYCOMB) {
					android.text.ClipboardManager clipboard = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					clipboard.setText(getLog());
				} else {
					android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE); 
					android.content.ClipData clip = android.content.ClipData.newPlainText("text label",getLog());
					clipboard.setPrimaryClip(clip);
				}
				Toast.makeText(SocksHttpMainActivity.this, "log copied", Toast.LENGTH_SHORT).show();
				return true;
			
			case R.id.miExit:
				if (Build.VERSION.SDK_INT >= 16) {
					finishAffinity();
				}
				
				System.exit(0);
			break;
		}

		return true;
	}

	
	
	public void prepareSharedData(){
        String chronometer = cmTimer.getText().toString();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("time", chronometer);
        editor.commit();
    }
	
	@Override
	public void onBackPressed() {
		showExitDialog();
		prepareSharedData();
		
	}

	protected void LogViewClear() {
            // Check if we need to clear the log
            if (mConfig.getAutoClearLog())
				SkStatus.clearLog();
			//mLogAdapter.clearLog();
    }
	
	@Override
    public void onResume() {
		new Timer().schedule(new TimerTask(){
				@Override
				public void run()
				{
					runOnUiThread(new Runnable()
						{

							@Override
							public void run()
							{
								/*boolean isRunning = SkStatus.isTunnelActive();
								if (SkStatus.isTunnelActive()) {
									mEditTextInput.setEnabled(!isRunning);
									}*/
				
								updateHeaderCallback();
								
							}
						});
					// TODO: Implement this method
				}
			}, 0,1000);
        super.onResume();
		cmTimer.setText(sharedPreferences.getString("time", "00h:00m:00s"));
		mTrafficSpeedMeasurer.registerListener(mStreamSpeedListener);
		liveData();
		updateReconnect();
		running();
		
		doUpdateLayout();
		
		SkStatus.addStateListener(this);
		
		/*if (adsBannerView != null) {
			adsBannerView.resume();
		}*/
    }

	@Override
	protected void onPause()
	{
		super.onPause();
		prepareSharedData();
		mTrafficSpeedMeasurer.removeListener(mStreamSpeedListener);
		doSaveData();
		
		SkStatus.removeStateListener(this);
		
		/*if (adsBannerView != null) {
			adsBannerView.pause();
		}*/
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		mTrafficSpeedMeasurer.stopMeasuring();
	//	mDrawer.onDestroy();

		LocalBroadcastManager.getInstance(this)
			.unregisterReceiver(mActivityReceiver);
			
		/*if (adsBannerView != null) {
			adsBannerView.destroy();
		}*/
	}


	/**
	 * DrawerLayout Listener
	 */

	@Override
	public void onDrawerOpened(View view) {
		if (view.getId() == R.id.activity_mainLogsDrawerLinear) {
			toolbar_main.getMenu().clear();
			getMenuInflater().inflate(R.menu.logs_menu, toolbar_main.getMenu());
		}
	}

	@Override
	public void onDrawerClosed(View view) {
		if (view.getId() == R.id.activity_mainLogsDrawerLinear) {
			toolbar_main.getMenu().clear();
			getMenuInflater().inflate(R.menu.main_menu, toolbar_main.getMenu());

		}
	}
	@Override
	public void onDrawerStateChanged(int stateId) {}
	@Override
	public void onDrawerSlide(View view, float p2) {}
	
	
	/**
	 * Utils
	 */

	public static void updateMainViews(Context context) {
		Intent updateView = new Intent(UPDATE_VIEWS);
		LocalBroadcastManager.getInstance(context)
			.sendBroadcast(updateView);
	}
	
	public void showExitDialog() {
		AlertDialog dialog = new AlertDialog.Builder(this).
			create();
		dialog.setTitle(getString(R.string.attention));
		dialog.setMessage(getString(R.string.alert_exit));

		dialog.setButton(DialogInterface.BUTTON_POSITIVE, getString(R.
				string.exit),
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					Utils.exitAll(SocksHttpMainActivity.this);
				}
			}
		);

		dialog.setButton(DialogInterface.BUTTON_NEGATIVE, getString(R.
				string.minimize),
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// minimiza app
					Intent startMain = new Intent(Intent.ACTION_MAIN);
					startMain.addCategory(Intent.CATEGORY_HOME);
					startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(startMain);
				}
			}
		);

		dialog.show();
	}
}

