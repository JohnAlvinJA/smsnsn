package com.mycompany.myapp3.weight;

import android.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.GridView;
import com.mycompany.myapp3.R;


public class ColorPickerDialog extends DialogFragment {

    private GridView gridView;
    private Context context;
    private int[][] colors = null;
    private AdapterView.OnItemClickListener onItemClickListener = null;

    
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {

        Window window = getDialog().getWindow();
        
        window.requestFeature(Window.FEATURE_NO_TITLE);
        View view = inflater.inflate(R.layout.dialog_color_picker, container, false);
        gridView = (GridView) view.findViewById(R.id.gridview_color);
        gridView.setAdapter(new ColorPickerAdapter(context, this.colors));
        gridView.setOnItemClickListener(this.onItemClickListener);
        return view;
    }

    
    public void setColors(int[][] colors){
        this.colors = colors;
    }

    
    public void setOnItemClickListener(AdapterView.OnItemClickListener onItemClickListener){
		this.onItemClickListener = onItemClickListener;
    }

}
