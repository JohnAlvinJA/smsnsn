package com.mycompany.myapp3.weight;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.mycompany.myapp3.R;

public class ColorPickerAdapter extends BaseAdapter {

    private Context context;
    private int[][] colors=null;

    public ColorPickerAdapter(Context context,int[][] colors) {
        this.context = context;
        this.colors = colors;
    }

    @Override
    public int getCount() {
        if (colors==null)
            return 0;
        return colors.length;
    }

    @Override
    public Object getItem(int position) {
        return colors[position][0];
    }

    @Override
    public long getItemId(int position) {
        return colors[position][1];
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        ViewHolder viewHolder;
        
        if (convertView == null) {
            view = View.inflate(context, R.layout.item_color_picker, null);
            viewHolder = new ViewHolder();
            viewHolder.imageView = (ImageView) view.findViewById(R.id.color_item);
            view.setTag(viewHolder);
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        
        viewHolder.imageView.setColorFilter(context.getResources().getColor(colors[position][0]));
        return view;
    }

    
    public final class ViewHolder {
        ImageView imageView;
    }
}
