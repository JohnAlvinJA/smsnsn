package com.mycompany.myapp3;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import com.mycompany.myapp3.weight.ColorPickerDialog;
import android.support.v7.app.*;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    
    public static int[][] colors = new int[][]{
		{R.color.material_blue, R.style.Theme_1},
		{R.color.material_light_blue, R.style.Theme_2},
		{R.color.material_pink, R.style.Theme_3},
		{R.color.material_red, R.style.Theme_4},
		{R.color.material_purple, R.style.Theme_5},
		{R.color.material_deep_purple, R.style.Theme_6},
		{R.color.material_teal, R.style.Theme_7},
		{R.color.material_deep_orange, R.style.Theme_8},
		{R.color.material_green, R.style.Theme_9},
		{R.color.material_cyan, R.style.Theme_10},
		{R.color.material_orange, R.style.Theme_11},
		{R.color.material_indigo, R.style.Theme_12},
		{R.color.material_brown, R.style.Theme_13},
		{R.color.material_blue_gray, R.style.Theme_14},
		{R.color.material_black, R.style.Theme_15}
    };

    private Context mContext;
	private Button a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        SharedPreferences sharedPreferences = getSharedPreferences("theme", Context.MODE_PRIVATE);
        setTheme(sharedPreferences.getInt("themeId",R.style.Theme_1));
        setContentView(R.layout.main);
        mContext = this;
		a = (Button) findViewById(R.id.a);
        a.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					switch (v.getId()){

						case R.id.a:
							ColorPickerDialog fagmmmu = new ColorPickerDialog();
							fagmmmu.setCancelable(true);
							fagmmmu.setColors(colors);
							fagmmmu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
									@Override
									public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
										SharedPreferences.Editor editor = getSharedPreferences("theme",Context.MODE_PRIVATE).edit();
										editor.putInt("themeId", (int)id);
										editor.apply();
									
										((Activity)mContext).finish();
										mContext.startActivity(new Intent(mContext, MainActivity.class));
									}
								});
							fagmmmu.show(getFragmentManager(),"fagmmmu");
							break;
						default:
							break;
					}

				}
			});}}
