# Android-CountDownTimer
CountDownTimer with pause and resume functions,the methods also are available in Java  
Also work with Service

![image](https://github.com/arjinmc/Android-CountDownTimer/blob/master/demo.png) 
