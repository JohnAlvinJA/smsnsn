package com.arjinmc.countdowntimer;

/**
 * CountDownTimerUtil
 * Created by Eminem Lu on 18/8/15.
 * Email arjinmc@hotmail.com
 */
public class CountDownTimerUtil {

    public static final int PREPARE = 0;
    public static final int START = 1;
    public static final int PASUSE = 2;
}
