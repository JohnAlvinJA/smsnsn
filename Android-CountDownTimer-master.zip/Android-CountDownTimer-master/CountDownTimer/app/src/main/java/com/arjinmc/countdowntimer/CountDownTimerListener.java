package com.arjinmc.countdowntimer;

/**
 * CountdownTimerListener
 * Created by Eminem Lu on 18/8/15.
 * Email arjinmc@hotmail.com
 */
public interface CountDownTimerListener {

    public void onChange();
}
