package com.slipkprojects.sockshttp;

import android.app.*;
import android.content.*;
import android.os.*;
import android.util.*;
import java.io.*;
import java.net.*;
import org.apache.http.client.methods.*;
import org.apache.http.*;
import org.apache.http.impl.client.*;
import org.apache.http.client.*;
import android.app.ProgressDialog;
import android.content.Context;

public class ja_updater extends AsyncTask<String, String, String> {
    private static final String TAG = "NetGuard.Download";
	private static final String PrivateKey = "Renz_FreeNet_PH";

    private Context context;

    private Listener listener;
    private PowerManager.WakeLock wakeLock;

    private HttpURLConnection uRLConnection;

    private InputStream is;

    private BufferedReader buffer;

    private String url;

    private ProgressDialog progressDialog;
    private boolean isOnCreate;
    
    public void start(boolean isOnCreate) {
        this.isOnCreate = isOnCreate;
        execute();
    }
    public interface Listener {
        void onLoading();
        void onCompleted(String config) throws Exception;

        void onCancelled();

        void onException(String ex);
    }

    public ja_updater(Context context, String url, Listener listener) {
        this.context = context;
        this.url = url;
        this.listener = listener;
    }

    @Override
    protected void onPreExecute() {
        if (!isOnCreate) {
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Please wait while loading");
            progressDialog.setTitle("Checking Update");
            progressDialog.setCancelable(false);
            progressDialog.show();       
    }}

    @Override
    protected String doInBackground(String... args) {
        try {
            String api = url;
            if(!api.startsWith("http")){
                api = new StringBuilder().append("http://").append(url).toString();
            }
            URL oracle = new URL(api);
            HttpClient Client = new DefaultHttpClient();
            HttpGet httpget = new HttpGet(oracle.toURI());
            HttpResponse response = Client.execute(httpget);
            InputStream in = response.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                                                           in, "iso-8859-1"), 8);

            //BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder str = new StringBuilder();
            String line = null;
            while((line = reader.readLine()) != null)
            {
                str.append(line);
            }
            in.close();
            return str.toString();
        } catch (Exception e) {
            return "error";
        } finally {
            if (buffer != null) {
                try {
                    buffer.close();
                } catch (IOException ignored) {
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException ignored) {

                }
            }
            if (uRLConnection != null) {
                uRLConnection.disconnect();
            }
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
		// Log.i(TAG, "Cancelled");
		// pd.dismiss();
        listener.onCancelled();
    }

    @Override
    protected void onPostExecute(String result) {
        // wakeLock.release();
        //nm.cancel(1);
		// pd.dismiss();
		Log.i(TAG, PrivateKey);
		Log.i(TAG, "error while verifying the privateKey");
       
        try
		{
        if (!isOnCreate && progressDialog != null) {
            progressDialog.dismiss();
        }
			if (result.equals("error"))
			{
				listener.onException(result);
			}
			else {
				listener.onCompleted(result);
			}
		}
		catch (Exception e)
		{
			listener.onException(e.getMessage());
		}
    }
	/**
	 * Created by Renz Vincent C. Mortel on 11/11/20
	 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
	 * associated documentation files (the "Software"), to deal in the Software without restriction,
	 * including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
	 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so,
	 * subject to the following conditions:
	 *
	 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
	 *
	 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
	 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
	 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH
	 * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
	 */
}



