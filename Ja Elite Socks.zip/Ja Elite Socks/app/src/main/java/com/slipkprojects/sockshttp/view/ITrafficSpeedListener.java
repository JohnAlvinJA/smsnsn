package com.slipkprojects.sockshttp.view;

public interface ITrafficSpeedListener {

    void onTrafficSpeedMeasured(double upStream, double downStream);
}
