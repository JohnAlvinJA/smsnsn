package com.slipkprojects.sockshttp.model;

import android.view.View;

public interface OnUpdateLayout {
	void updateLayout(View view);
}
