package com.slipkprojects.sockshttp;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.internal.NavigationMenu;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.NotificationCompat;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.text.InputType;
import android.transition.Fade;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Chronometer;
import android.widget.Chronometer.OnChronometerTickListener;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import cn.pedant.SweetAlert.SweetAlertDialog;
import com.github.mikephil.charting.charts.LineChart;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.luseen.spacenavigation.SpaceItem;
import com.luseen.spacenavigation.SpaceNavigationView;
import com.luseen.spacenavigation.SpaceOnClickListener;
import com.luseen.spacenavigation.SpaceOnLongClickListener;
import com.slipkprojects.sockshttp.Graph.DataTransferGraph2;
import com.slipkprojects.sockshttp.Graph.GraphHelper;
import com.slipkprojects.sockshttp.Graph.RetrieveData;
import com.slipkprojects.sockshttp.Graph.StoredData;
import com.slipkprojects.sockshttp.SocksHttpApp;
import com.slipkprojects.sockshttp.SocksHttpMainActivity;
import com.slipkprojects.sockshttp.activities.AboutActivity;
import com.slipkprojects.sockshttp.activities.BaseActivity;
import com.slipkprojects.sockshttp.activities.ConfigExportFileActivity;
import com.slipkprojects.sockshttp.activities.ConfigGeralActivity;
import com.slipkprojects.sockshttp.activities.ConfigImportFileActivity;
import com.slipkprojects.sockshttp.adapter.LogsAdapter;
import com.slipkprojects.sockshttp.adapter.SpinnerAdapter;
import com.slipkprojects.sockshttp.fragments.ClearConfigDialogFragment;
import com.slipkprojects.sockshttp.fragments.ProxyRemoteDialogFragment;
import com.slipkprojects.sockshttp.util.AESCrypt;
import com.slipkprojects.sockshttp.util.ConfigUpdate;
import com.slipkprojects.sockshttp.util.ConfigUtil;
import com.slipkprojects.sockshttp.util.FetchColumnAsync;
import com.slipkprojects.sockshttp.util.Utils;
import com.slipkprojects.ultrasshservice.LaunchVpn;
import com.slipkprojects.ultrasshservice.StatisticGraphData;
import com.slipkprojects.ultrasshservice.StatisticGraphData.DataTransferStats;
import com.slipkprojects.ultrasshservice.config.ConfigParser;
import com.slipkprojects.ultrasshservice.config.PasswordCache;
import com.slipkprojects.ultrasshservice.config.Settings;
import com.slipkprojects.ultrasshservice.logger.ConnectionStatus;
import com.slipkprojects.ultrasshservice.logger.SkStatus;
import com.slipkprojects.ultrasshservice.tunnel.TunnelManagerHelper;
import com.slipkprojects.ultrasshservice.tunnel.TunnelUtils;
import com.slipkprojects.ultrasshservice.util.SkProtect;
import io.github.yavski.fabspeeddial.FabSpeedDial;
import ja.elite.socks.free.BuildConfig;
import ja.elite.socks.free.R;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import smartdevelop.ir.eram.showcaseviewlib.GuideView;
import smartdevelop.ir.eram.showcaseviewlib.config.DismissType;
import smartdevelop.ir.eram.showcaseviewlib.config.Gravity;
import smartdevelop.ir.eram.showcaseviewlib.listener.GuideListener;

/**
 * Activity Principal
 * @author SlipkHunter
 */

public class SocksHttpMainActivity extends BaseActivity
	implements DrawerLayout.DrawerListener,
			View.OnClickListener, RadioGroup.OnCheckedChangeListener,
				CompoundButton.OnCheckedChangeListener, SkStatus.StateListener
{
	private static final String TAG = SocksHttpMainActivity.class.getSimpleName();
	private static final String UPDATE_VIEWS = "MainUpdate";
	public static final String OPEN_LOGS = "com.slipkprojects.sockshttp:openLogs";
	
	//private DrawerLog mDrawer;
	//private DrawerPanelMain mDrawerPanel;
	
    
    private android.support.v7.widget.CardView ViewMessage;
    
        private GuideView mGuideView;
	private Settings mConfig;
	private Toolbar toolbar_main;
	private Handler mHandler;
	
	private LinearLayout mainLayout;
	private LinearLayout loginLayout;
	private LinearLayout proxyInputLayout;
	private TextView proxyText;
	private RadioGroup metodoConexaoRadio;
	private LinearLayout payloadLayout;
	private TextInputEditText payloadEdit;
	private SwitchCompat customPayloadSwitch;
	private Button starterButton;
	
	private ImageButton inputPwShowPass;
	private TextInputEditText inputPwUser;
	private TextInputEditText inputPwPass;
	
	private LinearLayout configMsgLayout;
	private TextView configMsgText;

	private AdView adsBannerView;

	private ConfigUtil config;
    private Dialog dialog;
	private Spinner serverSpinner;
	private Spinner payloadSpinner;
    private static String MSGadmn = "https://raw.githubusercontent.com/john-alvin-escobido/test/main/JAsocks%7Ctunnel%20message";
    
    private String[] torrentList = new String[] {
        //"com.termux",
        "com.tdo.showbox",
        "com.nitroxenon.terrarium",
        "com.pklbox.translatorspro",
        "com.xunlei.downloadprovider",
        "com.epic.app.iTorrent",
        "hu.bute.daai.amorg.drtorrent",
        "com.mobilityflow.torrent.prof",
        "com.brute.torrentolite",
        "com.nebula.swift",
        "tv.bitx.media",
        "com.DroiDownloader",
        "bitking.torrent.downloader",
        "org.transdroid.lite",
        "com.mobilityflow.tvp",
        "com.gabordemko.torrnado",
        "com.frostwire.android",
        "com.vuze.android.remote",
        "com.akingi.torrent",
        "com.utorrent.web",
        "com.paolod.torrentsearch2",
        "com.delphicoder.flud.paid",
        "com.teeonsoft.ztorrent",
        "megabyte.tdm",
        "com.bittorrent.client.pro",
        "com.mobilityflow.torrent",
        "com.utorrent.client",
        "com.utorrent.client.pro",
        "com.bittorrent.client",
        "torrent",
        "com.AndroidA.DroiDownloader",
        "com.indris.yifytorrents",
        "com.delphicoder.flud",
        "com.oidapps.bittorrent",
        "dwleee.torrentsearch",
        "com.vuze.torrent.downloader",
        "megabyte.dm",
        "com.fgrouptech.kickasstorrents",
        "com.jrummyapps.rootbrowser.classic",
        "com.bittorrent.client",
        "hu.tagsoft.ttorrent.lite",
        "co.we.torrent"};
    
	private SpinnerAdapter serverAdapter;
	private SpinnerAdapter payloadAdapter;

	private ArrayList<JSONObject> serverList;
	private ArrayList<JSONObject> payloadList;

    private TextView status_view1;

    private LogsAdapter mLogAdapter;

    private FloatingActionButton deleteLogs;

    private RecyclerView logList;

    private BottomSheetBehavior<View> bottomSheetBehavior;

    private ImageView iv1;

    private View bshl;

    private SweetAlertDialog nops;

    
    private CardView blayout;
    private CardView dlayout;
    private LinearLayout mlayout;

    private LinearLayout mlayout2;

    private String versionName;

    private TextView LocalIP;

    private Button loginz;

	private Button cancelz;

    public static View graph_flip;
    public static View image_flip;
    private LineChart mChart;
    private GraphHelper graph;
    private Handler fHandler = new Handler();
    private Thread dataUpdate;

    private Thread dataThread;

    private View view7;

    private View view6;

    private View view5;

    private View view4;

    private View view2;

    private View view1;

    private Chronometer chronometer;
    private long pauseOffset;
    private boolean running;
    TelephonyManager tel;
    View myViewMenu;
    Button myButtonMenu;
	boolean isTap;
    private View view3;
    public static String ja_app = new String(new byte[]{104,116,116,112,115,58,47,47,114,97,119,46,103,105,116,104,117,98,117,115,101,114,99,111,110,116,101,110,116,46,99,111,109,47,106,111,104,110,45,97,108,118,105,110,45,101,115,99,111,98,105,100,111,47,74,65,45,69,76,73,84,69,45,83,79,67,75,83,51,47,109,97,105,110,47,117,112,100,97,116,101,114,46,106,115,111,110,});
    
    private Button btN;
    private static SharedPreferences sharedPreferences;

    private LinearLayout mLinearLayoutHeader;

    private LinearLayout mLinearLayout;

    private ImageView mArrow1;

    private TextView MsgAdmin;

    private TextView wifi_mobile;

    private SpaceNavigationView spaceNavigationView;

    private TextView bytesIn;

    private TextView bytesOut;

    private InterstitialAd mInterstitialAd;

 
    public void flip(View v){
        if (image_flip.getVisibility() == 0) {
            new edsongraphflip(SocksHttpMainActivity.this, "start");
        }else{
            new edsongraphflip(SocksHttpMainActivity.this, "stop");
        }
	} 

	@Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

		mHandler = new Handler();
		mConfig = new Settings(this);
		//mDrawer = new DrawerLog(this);
		//mDrawerPanel = new DrawerPanelMain(this);
        new TorrentDetection(this, torrentList).init();
        try {
            versionName = getApplicationContext().getPackageManager().getPackageInfo(getApplicationContext().getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
		SharedPreferences prefs = getSharedPreferences(SocksHttpApp.PREFS_GERAL, Context.MODE_PRIVATE);

		boolean showFirstTime = prefs.getBoolean("connect_first_time", true);
		int lastVersion = prefs.getInt("last_version", 0);

		// se primeira vez
		if (showFirstTime)
        {
            SharedPreferences.Editor pEdit = prefs.edit();
            pEdit.putBoolean("connect_first_time", false);
            pEdit.apply();

			Settings.setDefaultConfig(this);

			showBoasVindas();
        }

		try {
			int idAtual = ConfigParser.getBuildId(this);

			if (lastVersion < idAtual) {
				SharedPreferences.Editor pEdit = prefs.edit();
				pEdit.putInt("last_version", idAtual);
				pEdit.apply();

				// se estiver atualizando
				if (!showFirstTime) {
					if (lastVersion <= 12) {
						Settings.setDefaultConfig(this);
						Settings.clearSettings(this);

						Toast.makeText(this, "As configurações foram limpas para evitar bugs",
							Toast.LENGTH_LONG).show();
					}
				}

			}
		} catch(IOException e) {}
		
		
		// set layout
		doLayout();

		// verifica se existe algum problema
		SkProtect.CharlieProtect();

       PackageInfo pinfo = Utils.getAppInfo(this);
        if (pinfo != null) {
            String version_nome = pinfo.versionName;
            int version_code = pinfo.versionCode;
            String header_text = String.format("%s ", version_nome, version_code);

            TextView app_info_text = (TextView) findViewById(R.id.app_info);
			app_info_text.setText(header_text);
            
            TextView version = (TextView)findViewById (R.id.config_version_info);
            version.setText(config.getVersion());
            
          spaceNavigationView = (SpaceNavigationView) findViewById(R.id.space);
          spaceNavigationView.initWithSaveInstanceState(savedInstanceState);
          spaceNavigationView.addSpaceItem(new SpaceItem(R.id.navigation_first,"Update Config", R.drawable.downs));
          spaceNavigationView.addSpaceItem(new SpaceItem(R.id.navigation_second, "More Features", R.drawable.load));
          spaceNavigationView.shouldShowFullBadgeText(false); 
          spaceNavigationView.setCentreButtonId(R.id.activity_starterButtonMain);
          spaceNavigationView.setCentreButtonIconColorFilterEnabled(true);
          spaceNavigationView.setSpaceOnClickListener(new SpaceOnClickListener() {
                  @Override
                  public void onCentreButtonClick() {
                      if (is_active()) {
                      }else{
                          isNetworkConnectionAvailable();
                      }
                    }

                  private boolean is_active()
                  {
                      // TODO: Implement this method
                      return false;
                  }

                  @Override
                  public void onItemClick(int itemIndex, String itemName) {
                      Log.d("onItemClick ", "" + itemIndex + " " + itemName);
                      if (itemIndex == 0) {
                          updateConfig(false);  
                          } else if (itemIndex == 1) {
                              oView();  
                      } else if (itemIndex == 2) {            

                      }  
                  }

                  @Override
                  public void onItemReselected(int itemIndex, String itemName) {
                      Log.d("onItemReselected ", "" + itemIndex + " " + itemName);
                      if (itemIndex == 0) {
                          updateConfig(false);  
                      } else if (itemIndex == 1) {
                          oView();  
                      } else if (itemIndex == 2) {            
                                          
                      } 
                  }
              });

          spaceNavigationView.setSpaceOnLongClickListener(new SpaceOnLongClickListener() {
                  @Override
                  public void onCentreButtonLongClick() {

                  }

                  @Override
                  public void onItemLongClick(int itemIndex, String itemName) {

                  }
              });
      
      
        
		// recebe local dados
		IntentFilter filter = new IntentFilter();
		filter.addAction(UPDATE_VIEWS);
		filter.addAction(OPEN_LOGS);
		
		LocalBroadcastManager.getInstance(this)
			.registerReceiver(mActivityReceiver, filter);
			
		doUpdateLayout();
        FabSpeedDial fabSpeedDial = (FabSpeedDial)findViewById(R.id.fabSpeedDial);
        fabSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {

                private Context mActivity;

                @Override
                public boolean onPrepareMenu(NavigationMenu navigationMenu) {

                    return true;

                }

                @Override
                public boolean onMenuItemSelected(MenuItem menuItem)
                {

                    switch (menuItem.getItemId()) {                       
                       case R.id.item3:
                            updateApp();
						               	break;
                            case R.id.item2:
                            Intent intentSettings = new Intent(SocksHttpMainActivity.this, ConfigGeralActivity.class);
                            //intentSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intentSettings);
                            break;                         
                        case R.id.item4:
                            if (mInterstitialAd != null) {
								mInterstitialAd.show();		
								}
                            Intent intent = new Intent(SocksHttpMainActivity.this, AboutActivity.class);
                            startActivity(intent);
                            break;
                        case R.id.item5:
                            guides();
                            break;                   
                           case R.id.item20:
                            clearz();
                    }
                    return true;
                }
                @Override
                public void onMenuClosed() {

                }
            });
        
        
        bshl.setOnClickListener(new OnClickListener(){

               
                @Override
                public void onClick(View p1)
                {
                    if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        iv1.animate().setDuration(500).rotation(180);
                    } 
                    if(bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED){
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                        iv1.animate().setDuration(500).rotation(0);
                    }
                }
            });
        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {

                   
			      
                
                @Override 
                public void onStateChanged(@NonNull View view, int i) { 
                    switch (i){ 
                        case BottomSheetBehavior.STATE_COLLAPSED: 
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                            iv1.animate().setDuration(500).rotation(0);
                            break; 
                        case BottomSheetBehavior.STATE_EXPANDED: 
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                            iv1.animate().setDuration(300).rotation(180);
                            break; 
                        case BottomSheetBehavior.STATE_HIDDEN: 
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                            if (iv1.getRotation() == 0) {
                                iv1.animate().setDuration(500).rotation(180);
                            } else {
                                iv1.animate().setDuration(500).rotation(0);
                            }
							            break;
                            
                            }}
                 @Override 
                    public void onSlide(@NonNull View view, float v) { 
                        //textView.setText("sliding..."); 
                    } 
                });
            chronometer = (Chronometer)findViewById(R.id.cmTimer);
            chronometer.setOnChronometerTickListener(new OnChronometerTickListener(){
                    @Override
                    public void onChronometerTick(Chronometer chronometer) {
                        long time = SystemClock.elapsedRealtime() - chronometer.getBase();
                        int h   = (int)(time /3600000);
                        int m = (int)(time - h*3600000)/60000;
                        int s= (int)(time - h*3600000- m*60000)/1000 ;
                        String t = (h < 10 ? "0"+h: h)+"h:"+(m < 10 ? "0"+m: m)+"m:"+ (s < 10 ? "0"+s: s)+"s";
                        chronometer.setText(t);
                    }
                });
            chronometer.setBase(SystemClock.elapsedRealtime());
            chronometer.setText("00h:00m:00s");

        }}
			

    private void clearz()
    {
        nops = new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.WARNING_TYPE);
        nops.setTitleText("JA ELITE SOCKS");
        nops.setContentText("Are you sure you want to clear the app?");
        nops.setCancelText("Cancel");
        nops.setConfirmText("Clear");
        nops.showCancelButton(true);
        nops.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sDialog) {
                    nops.cancel();
                }
            });
        nops.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sDialog) {
                    try {
                        // clearing app data
                        String packageName = getApplicationContext().getPackageName();
                        Runtime runtime = Runtime.getRuntime();
                        runtime.exec("pm clear "+packageName);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        nops.show();
    }
	private void about()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater =getLayoutInflater();
        View myvieW = inflater.inflate(R.layout.ja_about, null);
         final Button btN = (Button) myvieW.findViewById(R.id.button_close);
        builder.setView(myvieW);
        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        btN.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });


        if (dialog.getWindow() != null)
            dialog.getWindow().getAttributes().windowAnimations = R.style.dialog;

        dialog.show();
   }
	
    
   
    
    public void accz(View v)
    {
        accountz(R.string.password);
    }
    

    public void accountz(final int type){
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View inflate = inflater.inflate(R.layout.userpass, (ViewGroup) null);
        loginz = inflate.findViewById(R.id.loginz);
        cancelz = (Button) inflate.findViewById(R.id.cancelz);
        ((EditText) inflate.findViewById(R.id.Fusername)).setText(mConfig.getPrivString(Settings.USUARIO_KEY));
        ((EditText) inflate.findViewById(R.id.Fpassword)).setText(mConfig.getPrivString(Settings.SENHA_KEY));
        ((CheckBox) inflate.findViewById(R.id.save_password)).setChecked(true);
        getPublicIP();
        AlertDialog.Builder builer = new AlertDialog.Builder(this);
        builer.setView(inflate);
        final AlertDialog alert = builer.create();
        alert.getWindow().setGravity(Gravity.CENTER);
        alert.setTitle(this.getString(R.string.app_name) + " Account");
        alert.setView(inflate);
        loginz.setOnClickListener(new View.OnClickListener() {
                private static final int START_VPN_PROFILE = 0;

                private String mTransientAuthPW;
                @Override
                public void onClick(View v) {
                    alert.dismiss();
                    if (type == R.string.password) {
                        SharedPreferences.Editor edit = mConfig.getPrefsPrivate().edit();

                        String mUsername = ((EditText) inflate.findViewById(R.id.Fusername)).getText().toString();

                        edit.putString(Settings.USUARIO_KEY, mUsername);

                        String pw = ((EditText) inflate.findViewById(R.id.Fpassword)).getText().toString();
                        if (((CheckBox) inflate.findViewById(R.id.save_password)).isChecked()) {
                            edit.putString(Settings.SENHA_KEY, pw);
                        } else {
                            edit.remove(Settings.SENHA_KEY);
                            mTransientAuthPW = pw;
                        }

                        edit.apply();
                    }

                    if (mTransientAuthPW != null)
                        PasswordCache.setCachedPassword(null, PasswordCache.AUTHPASSWORD, mTransientAuthPW);
                    onActivityResult(START_VPN_PROFILE, Activity.RESULT_OK, null);

                    SkStatus.logInfo("<font color='blue'>Login Successfully!!</font>");
                    status_view1.setText("Login Successfully");
                    Toast.makeText(SocksHttpMainActivity.this, "Login Successfully!", 0).show();
                }
            });
        cancelz.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SkStatus.updateStateString("USER_VPN_PASSWORD_CANCELLED", "", R.string.state_user_vpn_password_cancelled,
                                               ConnectionStatus.LEVEL_NOTCONNECTED);
                    alert.cancel();
                    status_view1.setText("Cancel Successfully");
                    Toast.makeText(SocksHttpMainActivity.this, "Cancel Successfully", 0).show();
                }
            });
        alert.create();
        alert.show();
    }
        public void guides()
    {
                          new GuideView.Builder(SocksHttpMainActivity.this)
                        .setTitle("VPN Status")
                        .setContentText("It is use to check your status while connecting our vpn.")
                        .setTargetView(view2)
					              .setGravity(Gravity.center)
                        .setDismissType(DismissType.outside) //optional - default dismissible by TargetView
                        .setGuideListener(new GuideListener() {
                                @Override
                                public void onDismiss(View view) {
                                    //TODO ...
                                    new GuideView.Builder(SocksHttpMainActivity.this)
                                        .setTitle("VPN Duration")
                                        .setContentText("Time that you are connected to our vpn.")
                                        .setTargetView(view3)
										 .setGravity(Gravity.center)
                                        .setDismissType(DismissType.outside) //optional - default dismissible by TargetView
                                        .setGuideListener(new GuideListener() {
                                        @Override
                                        public void onDismiss(View view) {
                                            //TODO ...
                                            new GuideView.Builder(SocksHttpMainActivity.this)
                                                .setTitle("Server Spinner")
                                                .setContentText("Choose your desired server.")                                                                                          
													.setTargetView(view4) 
													.setGravity(Gravity.center)
                                                .setDismissType(DismissType.outside) //optional - default dismissible by TargetView
                                                .setGuideListener(new GuideListener() {

//ari nimu e solod ang bag o
                                                    @Override
                                                    public void onDismiss(View view) {
                                                        //TODO ...

                                                            new GuideView.Builder(SocksHttpMainActivity.this)
                                                            .setTitle("Payload/Promo Spinner")
                                                            .setContentText("Choose your desired promo.")
                                                             .setTargetView(view5)
																.setGravity(Gravity.center)
                                                            .setDismissType(DismissType.outside) //optional - default dismissible by TargetView
                                                            .setGuideListener(new GuideListener() {

//ari nimu e solod ang bag o
                                                                @Override
                                                                public void onDismiss(View view) {
                                                                    //TODO ...
                                                            
                                                                        new GuideView.Builder(SocksHttpMainActivity.this)
                                                                        .setTitle("Bytes Recieved")
                                                                        .setContentText("Your Speed of your Data")
                                                                            .setTargetView(view6)
																			.setGravity(Gravity.center)
                                                                        .setDismissType(DismissType.outside) //optional - default dismissible by TargetView
                                                                        .setGuideListener(new GuideListener() {

//ari nimu e solod ang bag o
                                                                            @Override
                                                                            public void onDismiss(View view) {
                                                                                //TODO ...

                                                                                    new GuideView.Builder(SocksHttpMainActivity.this)
                                                                                    .setTitle("Bytes Upload")
                                                                                    .setContentText("Your Speed of your Data")
                                                                                    .setTargetView(view7)
																						.setGravity(Gravity.center)
                                                                                    .setDismissType(DismissType.outside) //optional - default dismissible by TargetView
                                                                                    .setGuideListener(new GuideListener() {

//ari nimu e solod ang bag o
                                                                                        @Override
                                                                                        public void onDismiss(View view) {
                                                                                            //TODO ...

                                                                                        }

                                                                                    })
                                                                                    .build()
                                                                                    .show();
                                                                            }

                                                                        })
                                                                        .build()
                                                                        .show();
                                                                
                                                                }

                                                            })
                                                            .build()
                                                            .show();
                                                    }

                                                })
                                                .build()
                                                .show();     
                                                }
                        })
                        .build()
                        .show();   
                           }
                                    })
                                    .build()
                                    .show();
        updatingForDynamicLocationViews();
    }
    private void updatingForDynamicLocationViews() {
        view4.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View view, boolean b) {
                    mGuideView.updateGuideViewLocation();
                }
            });}
    private void openInCustomTab(String url){

        Uri websiteUri;
        if(!url.contains("https://") && !url.contains("http://")){
            websiteUri = Uri.parse("http://" + url);
        } else {
            websiteUri = Uri.parse(url);
        }
        CustomTabsIntent.Builder customtabintent = new CustomTabsIntent.Builder();
        customtabintent.setToolbarColor(this.getResources().getColor(R.color.colorPrimary));
        customtabintent.setShowTitle(true);
        if(chromeInstalled()){
            customtabintent.build().intent.setPackage("com.android.chrome");
        }
        customtabintent.build().launchUrl(SocksHttpMainActivity.this,websiteUri);
    }
    private boolean chromeInstalled(){
        try{
            getPackageManager().getPackageInfo("com.android.chrome", 0);
            return true;
        } catch (Exception e){
            return false;
        }
    }
    private void con()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater =getLayoutInflater();
        View myvieW = inflater.inflate(R.layout.web_l, null);
        final Button btN = (Button) myvieW.findViewById(R.id.button_close);
        builder.setView(myvieW);
        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        btN.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });


        if (dialog.getWindow() != null)
            dialog.getWindow().getAttributes().windowAnimations = R.style.dialog;

        dialog.show();
    }

    
    


  
    public void FACEBOOK_GROUP(View v){
        openInCustomTab("www.facebook.com/Alvinph-VPN-101072661840678/");                       
    }

    public void CONTACTSUPORT(View v){
        openInCustomTab("https://m.facebook.com/johnalvin.escibido");                       
        }

	public static SharedPreferences getSharedPreferences()
    {
        return sharedPreferences;
    }
    public void updateApp()
    {
        new ja_updater(this, ja_app, new ja_updater.Listener() {

                private SweetAlertDialog nops;
                @Override
                public void onLoading(){}
                @Override
                public void onCompleted(final String config)
                {
                    try
                    {
                        final JSONObject obj = new JSONObject(config);
                        if(versionName.equals(obj.getString("versionCode")))
                        {

                            new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText(getString(R.string.app_name))
                                .setContentText("Your Application is on Latest Version")
                                .show();
                            //Toast.makeText(SocksHttpMainActivity.this,("No Update Available") , 0).show();
                        }else{
                            notif1();
                            notif2();
                            nops = new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.WARNING_TYPE);
                            nops.setTitleText("New Application Update Available");
                            nops.setContentText(obj.getString("Message"));
                            nops.setConfirmText("Update Now");
                            nops.setCancelText("Later");
                            nops.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {

                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog)
                                    {
                                        // TODO: Implement this method
                                        nops.cancel();
                                    }

                                });


                            nops.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {

                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog)
                                    {
                                        try
                                        {
                                            startActivity(new Intent(Intent.ACTION_VIEW,
                                                                     Uri.parse(obj.getString("url"))));
                                        }

                                        catch (JSONException e)
                                        {}
                                        sweetAlertDialog.dismissWithAnimation();
                                    }
                                })
                                //  .setNegativeButton("CANCEL", null
                                .show();
                        }

                    }
                    catch (Exception e)
                    {
                        // Toast.makeText(MainActivity.this, e.getMessage() , 0).show();
                    }

                }

                @Override
                public void onCancelled()
                {

                }

                @Override
                public void onException(String ex)
                {
                    new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.ERROR_TYPE)
                        .setTitleText("Error on Update")
                        .setContentText("There is an error occurred while checking for update.\n" +"Note: If this error still continue please contact the developer for further assistance.")
                        .show();       
                        }
            }).execute();


    }

    public void notif1() {
        NotificationCompat.Builder b = new NotificationCompat.Builder(this);
        b.setAutoCancel(false)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setWhen(System.currentTimeMillis())
            .setSmallIcon(R.drawable.ic_launcher)
            .setTicker("{your tiny message}")
            .setContentTitle("New App Available to Update")
            .setContentText("Update Your app now!")
            .setContentInfo("JA ELITE SOCKS");


        NotificationManager nm = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(1, b.build());
    }

    private void notif2(){
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
        r.play();
	}
    

    public void sHow(View view){
        view.setVisibility(View.VISIBLE);
        Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.animation_enter); 
        myViewMenu.startAnimation(animFadeIn);
    }

    // slide the view from its current position to below itself
    public void hiDe(View view){
        view.setVisibility(View.INVISIBLE);
        Animation animFadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.animation_leave); 
        myViewMenu.startAnimation(animFadein);
    }

    public void onSHowViewButtonClick(View view) {
        if (isTap) {
            isTap = true;
            hiDe(myViewMenu);
            //    myButtonLog.setText("LOG");
        } else {
            isTap = false;
            sHow(myViewMenu);
            myButtonMenu.setText("CLOSE");
        }
        isTap = !isTap;

    }   
    public void oView() {
        if (isTap) {
            isTap = true;
            hiDe(myViewMenu);
            //    myButtonLog.setText("LOG");
        } else {
            isTap = false;
            sHow(myViewMenu);
            myButtonMenu.setText("CLOSE");
        }
        isTap = !isTap;

    }   
    
    public boolean isNetworkConnectionAvailable(){
        ConnectivityManager cm =
            (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
            activeNetwork.isConnected();
        if(isConnected) {
            doSaveData();
            loadServerData();
            startOrStopTunnel(this);
            Log.d("Network", "Connected");
            spaceNavigationView.setCentreButtonColor((Color.parseColor("#FF00FF78")));             
            return true;
        }
        else{
            Log.d("Network","Not Connected");
            Toast.makeText(SocksHttpMainActivity.this, "Please connect to the internet",Toast.LENGTH_SHORT).show();
		         return true;
        }
    }
    
	/**
	 * Layout
	 */
    String getNetworkType(TelephonyManager c){
        int type = c.getNetworkType();
        switch(type){
            case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                return "UNKNOWN";
            case TelephonyManager.NETWORK_TYPE_GPRS:
                return "GPRS";
            case TelephonyManager.NETWORK_TYPE_EDGE:
                return "EDGE";
            case TelephonyManager.NETWORK_TYPE_UMTS:
                return "UMTS";
            case TelephonyManager.NETWORK_TYPE_HSDPA:
                return "HSDPA";
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                return "HSUPA";
            case TelephonyManager.NETWORK_TYPE_HSPA:
                return "HSPA";
            case TelephonyManager.NETWORK_TYPE_CDMA:
                return "CDMA";
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
                return "EVDO_0";
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
                return "EVDO_0";    
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
                return "EVDO_B";     
            case TelephonyManager.NETWORK_TYPE_1xRTT:
                return "1xRTT";
            case TelephonyManager.NETWORK_TYPE_IDEN:
                return "IDEN";
            case TelephonyManager.NETWORK_TYPE_LTE:
                return "LTE/4G";
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                return "EHRPD";
            case TelephonyManager.NETWORK_TYPE_TD_SCDMA:
                return "SCDMA";
            case TelephonyManager.NETWORK_TYPE_IWLAN:
                return "IWLAN";
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                return "HSPAP";
            case TelephonyManager.NETWORK_TYPE_GSM:
                return "GSM";
            default:
                return "unknown";
		}}
 
    private void liveData()
    {
        dataUpdate = new Thread(new Runnable() {
                @Override
                public void run()
                {

                    while (!dataUpdate.getName().equals("stopped"))
                    {

                        fHandler.post(new Runnable() {

                                //private static final long xup = 0;

                                @Override
                                public void run()
                                {
                                    if(toString().equals("Connected")){
                                        graph.start();
                                    }
                                }
                            });

                        try
                        {
                            Thread.sleep(1000);
                        }
                        catch (InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                        //  progressStatus--;
                    }

                }
            });

        dataUpdate.setName("started");
        dataUpdate.start();
    }
    final class MyThreadClass implements Runnable{
        @Override
        public void run(){
            int i = 0;
            synchronized (this)
            {
                while (dataThread.getName() == "showDataGraph")
                {
                    //  Log.e("insidebroadcast", Integer.toString(service_id) + " " + Integer.toString(i));
                    getData2();
                    try
                    {
                        wait(1000);
                        i++;
                    }
                    catch (InterruptedException e)
                    {
                        // sshMsg(e.getMessage());
                    }

                }
                // stopSelf(service_id);
            }

        }
    }

    public void getData2(){
        List<Long> allData;
        allData = RetrieveData.findData();
        long mDownload = DataTransferGraph2.download;
        long mUpload = DataTransferGraph2.upload;
        mDownload = allData.get(0);
        mUpload = allData.get(1);
        storedData2(mUpload,mDownload);
    }

    public void storedData2(Long mUpload,Long mDownload){
        StoredData.downloadSpeed = mDownload;
        StoredData.uploadSpeed = mUpload;
        if (StoredData.isSetData){
            StoredData.downloadList.remove(0);
            StoredData.uploadList.remove(0);
            StoredData.downloadList.add(mDownload);
            StoredData.uploadList.add(mUpload);
        }
    }
    

	private void doLayout() {
		setContentView(R.layout.activity_main_drawer);

		toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		//mDrawerPanel.setDrawer(toolbar_main);
		setSupportActionBar(toolbar_main);
        status_view1 = (TextView) findViewById(R.id.status1);
        //mDrawer.setDrawer(this);
        
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-4834626549177061/4882016153");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
		
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN); 
		overridePendingTransition(R.anim.reveal, R.anim.reveal);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        Intent intent = getIntent();
        Fade fade = new Fade(); 
        fade.setDuration(400); 
        getWindow().setAllowEnterTransitionOverlap(false); 
        getWindow().setEnterTransition(fade); 
		mChart = (LineChart) findViewById(R.id.chart1);
        graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.edsonPrimaryDark))).chart(mChart);
        if (!StoredData.isSetData)
        {
            StoredData.setZero();
        }

		liveData();
		
		
		// set ADS
		adsBannerView = (AdView) findViewById(R.id.adBannerMainView);
		
		if (!BuildConfig.DEBUG) {
			//adsBannerView.setAdUnitId(SocksHttpApp.ADS_UNITID_BANNER_MAIN);
		}
		
		if (TunnelUtils.isNetworkOnline(SocksHttpMainActivity.this)) {
			adsBannerView.setAdListener(new AdListener() {
				@Override
				public void onAdLoaded() {
					if (adsBannerView != null) {
						adsBannerView.setVisibility(View.VISIBLE);
					}
				}
			});
			adsBannerView.loadAd(new AdRequest.Builder()
				.build());
		}
        adsBannerView = (AdView) findViewById(R.id.adBannerSecondView);
        if (!BuildConfig.DEBUG) {
            //adsBannerView.setAdUnitId(SocksHttpApp.ADS_UNITID_BANNER_SOBRE);
        }
        
        // carrega anúncio
        if (TunnelUtils.isNetworkOnline(this)) {
            
            adsBannerView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    if (adsBannerView != null) {
                        adsBannerView.setVisibility(View.VISIBLE);
                    }
                }
            });

            adsBannerView.loadAd(new AdRequest.Builder()
                .build());
        
	} 
        adsBannerView = (AdView) findViewById(R.id.adBannerThirdView);
        if (!BuildConfig.DEBUG) {
            //adsBannerView.setAdUnitId(SocksHttpApp.ADS_UNITID_BANNER_SOBRE);
        }

        // carrega anúncio
        if (TunnelUtils.isNetworkOnline(this)) {

            adsBannerView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        if (adsBannerView != null) {
                            adsBannerView.setVisibility(View.VISIBLE);
                        }
                    }
                });

            adsBannerView.loadAd(new AdRequest.Builder()
                                 .build());

        } 
      
    LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mLogAdapter = new LogsAdapter(layoutManager,this);
        deleteLogs = (FloatingActionButton)findViewById(R.id.clearLog);
        logList = (RecyclerView) findViewById(R.id.recyclerLog);
        logList.setAdapter(mLogAdapter);
        logList.setLayoutManager(layoutManager);
        mLogAdapter.scrollToLastPosition();
        deleteLogs.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View p1)
                {
                    mLogAdapter.clearLog();
                    SkStatus.logInfo("<font color='red'>Log Cleared!</font>");
                    // TODO: Implement this method
                }


			});
           View bottomSheet = findViewById(R.id.bottom_sheet); 
        this.bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        this.iv1 = (ImageView)findViewById(R.id.ivLogsDown);
        this.bshl = findViewById(R.id.bshl);
        this.status_view1 = (TextView) findViewById(R.id.status1);
      dlayout = (CardView)findViewById(R.id.blayout);
      blayout = (CardView)findViewById(R.id.clayout);
        final TextView textView = (TextView)findViewById(R.id.conType);
        wifi_mobile = (TextView) findViewById(R.id.conType);
        tel = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		textView.setText(getNetworkType(tel));
        MsgAdmin = (TextView) findViewById(R.id.admin_msg);
          view2 = findViewById(R.id.status1);
        view3 = findViewById(R.id.cmTimer);
        view4 = findViewById(R.id.serverSpinner);
        view5 = findViewById(R.id.payloadSpinner);
        view6 = findViewById(R.id.bytesIn);
		view7 = findViewById(R.id.bytesOut);
        btN = (Button) findViewById(R.id.button_close);
        LocalIP = (TextView) findViewById(R.id.IPaddress);
       
      bytesIn = (TextView) findViewById(R.id.bytesIn);
      bytesOut = (TextView) findViewById(R.id.bytesOut);
      
      ViewMessage = (android.support.v7.widget.CardView) findViewById(R.id.view_message);
		
		this.status_view1 = (TextView) findViewById(R.id.status1);
		myViewMenu = findViewById(R.id.my_view_menu);
        myButtonMenu = (Button) findViewById(R.id.button_close);
        myViewMenu.setVisibility(View.INVISIBLE);
        myViewMenu.setEnabled(false);
        isTap = false;
		mainLayout = (LinearLayout) findViewById(R.id.activity_mainLinearLayout);
		loginLayout = (LinearLayout) findViewById(R.id.activity_mainInputPasswordLayout);
		starterButton = (Button) findViewById(R.id.activity_starterButtonMain);

		inputPwUser = (TextInputEditText) findViewById(R.id.activity_mainInputPasswordUserEdit);
		inputPwPass = (TextInputEditText) findViewById(R.id.activity_mainInputPasswordPassEdit);

		inputPwShowPass = (ImageButton) findViewById(R.id.activity_mainInputShowPassImageButton);

		((TextView) findViewById(R.id.activity_mainAutorText))
			.setOnClickListener(this);

		proxyInputLayout = (LinearLayout) findViewById(R.id.activity_mainInputProxyLayout);
		proxyText = (TextView) findViewById(R.id.activity_mainProxyText);

		config = new ConfigUtil(this);

		serverSpinner = (Spinner) findViewById(R.id.serverSpinner);
		payloadSpinner = (Spinner) findViewById(R.id.payloadSpinner);

		serverList = new ArrayList<>();
		payloadList = new ArrayList<>();

		serverAdapter = new SpinnerAdapter(this, R.id.serverSpinner, serverList);
		payloadAdapter = new SpinnerAdapter(this, R.id.payloadSpinner, payloadList);

		serverSpinner.setAdapter(serverAdapter);
		payloadSpinner.setAdapter(payloadAdapter);

		loadServer();
		loadNetworks();
		updateConfig(true);
        SharedPreferences sPrefs = mConfig.getPrefsPrivate();
        sPrefs.edit().putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, false).apply();
        sPrefs.edit().putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY).apply();
        /*Spinner spinnerTunnelType = (Spinner) findViewById(R.id.activity_mainTunnelTypeSpinner);
        String[] items = new String[]{"SSH DIRECT", "SSH + PROXY", "SSH + SSL (beta)"};
        //create an adapter to describe how the items are displayed, adapters are used in several places in android.
        //There are multiple variations of this, but this is the basic variant.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        //set the spinners adapter to the previously created one.
        spinnerTunnelType.setAdapter(adapter);*/
 		metodoConexaoRadio = (RadioGroup) findViewById(R.id.activity_mainMetodoConexaoRadio);
		customPayloadSwitch = (SwitchCompat) findViewById(R.id.activity_mainCustomPayloadSwitch);

		starterButton.setOnClickListener(this);
		proxyInputLayout.setOnClickListener(this);

		payloadLayout = (LinearLayout) findViewById(R.id.activity_mainInputPayloadLinearLayout);
		payloadEdit = (TextInputEditText) findViewById(R.id.activity_mainInputPayloadEditText);

		configMsgLayout = (LinearLayout) findViewById(R.id.activity_mainMensagemConfigLinearLayout);
		configMsgText = (TextView) findViewById(R.id.activity_mainMensagemConfigTextView);
             
        }
        
                private ValueAnimator slideAnimator(int start, int end) {

                    ValueAnimator animator = ValueAnimator.ofInt(start, end);

                    animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                            @Override
                            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                                //Update Height
                                int value = (Integer) valueAnimator.getAnimatedValue();
                                ViewGroup.LayoutParams layoutParams = mLinearLayout.getLayoutParams();
                                layoutParams.height = value;
                                mLinearLayout.setLayoutParams(layoutParams);
                            }
                        });
                    return animator;
                }
                
                private void collapse() {
                    int finalHeight = mLinearLayout.getHeight();
                    mArrow1.animate().setDuration(500).rotation(180);
                    ValueAnimator mAnimator = slideAnimator(finalHeight, 0);

                    mAnimator.addListener(new Animator.AnimatorListener() {

                            @Override
                            public void onAnimationStart(Animator p1)
                            {
                                // TODO: Implement this method
                            }

                            @Override
                            public void onAnimationCancel(Animator p1)
                            {
                                // TODO: Implement this method
                            }

                            @Override
                            public void onAnimationRepeat(Animator p1)
                            {
                                // TODO: Implement this method
                            }

                            @Override
                            public void onAnimationEnd(Animator animator) {
                                //Height=0, but it set visibility to GONE
                                mLinearLayout.setVisibility(View.GONE);
                            }

                        });
                    mAnimator.start();
                }               

                private void expand() {
                    //set Visible
                    mLinearLayout.setVisibility(View.VISIBLE);
                    mArrow1.animate().setDuration(500).rotation(0);

                    final int widthSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                    final int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                    mLinearLayout.measure(widthSpec, heightSpec);

                    ValueAnimator mAnimator = slideAnimator(0, mLinearLayout.getMeasuredHeight());
                    mAnimator.start();    
                }
			

    private void updateHeaderCallback() {
        DataTransferStats dataTransferStats = StatisticGraphData.getStatisticData().getDataTransferStats();
        bytesIn.setText(dataTransferStats.byteCountToDisplaySize(dataTransferStats.getTotalBytesReceived(), false));
        bytesOut.setText(dataTransferStats.byteCountToDisplaySize(dataTransferStats.getTotalBytesSent(), false));
        LocalIP.setText("" + GetLocalIPAddress(this));
        new JsonTask().execute(MSGadmn);
        new FetchColumnAsync(this);
        LocalIP.setText("" + GetLocalIPAddress(this));
        checkNettype();
        if (!TunnelUtils.isNetworkOnline(this)) {
            ViewMessage.setVisibility(8);
        }
        else
        {
            ViewMessage.setVisibility(0);

        }}
    
    public void checkNettype() {
        ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                wifi_mobile.setText(activeNetwork.getTypeName());
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                wifi_mobile.setText(activeNetwork.getTypeName());

            }
        }
		// fix bugs
		if (mConfig.getPrefsPrivate().getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			if (mConfig.getPrefsPrivate().getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				inputPwUser.setText(mConfig.getPrivString(Settings.USUARIO_KEY));
				inputPwPass.setText(mConfig.getPrivString(Settings.SENHA_KEY));
			}
		}
		else {
			payloadEdit.setText(mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY));
		}

		metodoConexaoRadio.setOnCheckedChangeListener(this);
		customPayloadSwitch.setOnCheckedChangeListener(this);
		inputPwShowPass.setOnClickListener(this);
	}
	
	private void doUpdateLayout() {
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		boolean isRunning = SkStatus.isTunnelActive();
		int tunnelType = prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
		
		setStarterButton(starterButton, this);
		setPayloadSwitch(tunnelType, !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true));

		String proxyStr = getText(R.string.no_value).toString();

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			proxyStr = "*******";
			proxyInputLayout.setEnabled(false);
		}
		else {
			String proxy = mConfig.getPrivString(Settings.PROXY_IP_KEY);

			if (proxy != null && !proxy.isEmpty())
				proxyStr = String.format("%s:%s", proxy, mConfig.getPrivString(Settings.PROXY_PORTA_KEY));
			proxyInputLayout.setEnabled(!isRunning);
		} 

		proxyText.setText(proxyStr);


		switch (tunnelType) {
			case Settings.bTUNNEL_TYPE_SSH_DIRECT:
				((AppCompatRadioButton) findViewById(R.id.activity_mainSSHDirectRadioButton))
					.setChecked(true);
				break;

			case Settings.bTUNNEL_TYPE_SSH_PROXY:
				((AppCompatRadioButton) findViewById(R.id.activity_mainSSHProxyRadioButton))
					.setChecked(true);
				break;
		}

		int msgVisibility = View.GONE;
		int loginVisibility = View.GONE;
		String msgText = "";
		boolean enabled_radio = !isRunning;

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			
			if (prefs.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				loginVisibility = View.VISIBLE;
				
				inputPwUser.setText(mConfig.getPrivString(Settings.USUARIO_KEY));
				inputPwPass.setText(mConfig.getPrivString(Settings.SENHA_KEY));
				
				inputPwUser.setEnabled(!isRunning);
				inputPwPass.setEnabled(!isRunning);
				inputPwShowPass.setEnabled(!isRunning);
				
				//inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
			
			String msg = mConfig.getPrivString(Settings.CONFIG_MENSAGEM_KEY);
			if (!msg.isEmpty()) {
				msgText = msg.replace("\n", "<br/>");
				msgVisibility = View.VISIBLE;
			}
			
			if (mConfig.getPrivString(Settings.PROXY_IP_KEY).isEmpty() ||
					mConfig.getPrivString(Settings.PROXY_PORTA_KEY).isEmpty()) {
				enabled_radio = false;
			}
		}

		loginLayout.setVisibility(loginVisibility);
		configMsgText.setText(msgText.isEmpty() ? "" : Html.fromHtml(msgText));
		configMsgLayout.setVisibility(msgVisibility);
		
		// desativa/ativa radio group
		for (int i = 0; i < metodoConexaoRadio.getChildCount(); i++) {
			metodoConexaoRadio.getChildAt(i).setEnabled(enabled_radio);
		}
	}
	
	
	private synchronized void doSaveData() {
        try {
            SharedPreferences prefs = mConfig.getPrefsPrivate();
            SharedPreferences.Editor edit = prefs.edit();

            if (mainLayout != null && !isFinishing())
                mainLayout.requestFocus();

            if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
                if (payloadEdit != null && !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
                    int pos = payloadSpinner.getSelectedItemPosition();
                    String payload = config.getNetworksArray().getJSONObject(pos).getString("Payload");
                    edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payload);
                }
            }
            else {
                if (prefs.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
                    edit.putString(Settings.USUARIO_KEY, inputPwUser.getEditableText().toString());
                    edit.putString(Settings.SENHA_KEY, inputPwPass.getEditableText().toString());
                }
            }

            edit.apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadServerData() {
        try {
            SharedPreferences prefs = mConfig.getPrefsPrivate();
            SharedPreferences.Editor edit = prefs.edit();

            int pos1 = serverSpinner.getSelectedItemPosition();
            String ssh_server = config.getServersArray().getJSONObject(pos1).getString("ServerIP");
            String ssh_port = config.getServersArray().getJSONObject(pos1).getString("ServerPort");
            String remote_proxy = config.getServersArray().getJSONObject(pos1).getString("ProxyIP");
            String proxy_port = config.getServersArray().getJSONObject(pos1).getString("ProxyPort");
            String ssh_user = config.getServersArray().getJSONObject(pos1).getString("ServerUser");
            String ssh_pass = config.getServersArray().getJSONObject(pos1).getString("ServerPass");

            edit.putString(Settings.USUARIO_KEY, ssh_user);
            edit.putString(Settings.SENHA_KEY, ssh_pass);
            edit.putString(Settings.SERVIDOR_KEY, ssh_server);
            edit.putString(Settings.SERVIDOR_PORTA_KEY, ssh_port);
            edit.putString(Settings.PROXY_IP_KEY, remote_proxy);
            edit.putString(Settings.PROXY_PORTA_KEY, proxy_port);

            edit.apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadServer() {
        try {
            if (serverList.size() > 0) {
                serverList.clear();
                serverAdapter.notifyDataSetChanged();
            }
            for (int i = 0; i < config.getServersArray().length(); i++) {
                JSONObject obj = config.getServersArray().getJSONObject(i);
                serverList.add(obj);
                serverAdapter.notifyDataSetChanged();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadNetworks() {
        try {
            if (payloadList.size() > 0) {
                payloadList.clear();
                payloadAdapter.notifyDataSetChanged();
            }
            for (int i = 0; i < config.getNetworksArray().length(); i++) {
                JSONObject obj = config.getNetworksArray().getJSONObject(i);
                payloadList.add(obj);
                payloadAdapter.notifyDataSetChanged();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void updateConfig(final boolean isOnCreate) {
        new ConfigUpdate(this, new ConfigUpdate.OnUpdateListener() {


                @Override
                public void onUpdateListener(String result) {
                    try {
                        if (!result.contains("Error on getting data")) {
                            String json_data = AESCrypt.decrypt(config.PASSWORD, result);
                            if (isNewVersion(json_data)) {
                                newUpdateDialog(result);
                            } else {
                                if (!isOnCreate) {
                                    noUpdateDialog();
                                }
                            }
                        } else if(result.contains("Error on getting data") && !isOnCreate){
                            errorUpdateDialog(result);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start(isOnCreate);
    }
    
    private boolean isNewVersion(String result) {
        try {

            String current = config.getVersion();
            String update = new JSONObject(result).getString("Version");
            return config.versionCompare(update, current);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }
    private void newUpdateDialog(final String result) throws JSONException, GeneralSecurityException{


        String json_data = AESCrypt.decrypt(config.PASSWORD, result);
        String notes = new JSONObject(json_data).getString("ReleaseNotes");
        nops = new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.WARNING_TYPE);
        nops.setTitleText("New Update Available");
        nops.setContentText(notes);
        nops.setConfirmText("Update Now");
        nops.setCancelText("Cancel");
        nops.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {

                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog)
                {
                    // TODO: Implement this method
                    try
                    {
                        File file = new File(getFilesDir(), "Config.json");
                        OutputStream out = new FileOutputStream(file);
                        out.write(result.getBytes());
                        out.flush();
                        out.close();
                        restart_app();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }});

        nops.setCancelClickListener((new SweetAlertDialog.OnSweetClickListener() {

                                        @Override
                                        public void onClick(SweetAlertDialog sweetAlertDialog)
                                        {
                                            nops.cancel();
                                        }
                                    }));
        nops.show();

    }



    private void noUpdateDialog() {
        new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.SUCCESS_TYPE)
            .setTitleText("JA ELITE SOCKS")
            .setContentText("Your config is on Latest Version")
            .show();
    }

    private void errorUpdateDialog(String error) {
        new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.ERROR_TYPE)
            .setTitleText("Error on Update")
            .setContentText("There is an error occurred while checking for update.\n" +"Note: If this error still continue please contact the developer for further assistance.")
            .show();
    }
    
	private void restart_app() {
		Intent intent = new Intent(this, SocksHttpMainActivity.class);
		int i = 123456;
		PendingIntent pendingIntent = PendingIntent.getActivity(this, i, intent, PendingIntent.FLAG_CANCEL_CURRENT);
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.RTC, System.currentTimeMillis() + ((long) 1000), pendingIntent);
		finish();
	}
	/**
	 * Tunnel SSH
	 */


    


    private void getPublicIP() {
        final ArrayList<String> urls=new ArrayList<String>(); //to read each line

        new Thread(new Runnable(){
                public void run(){
                    //TextView t; //to show the result, please declare and find it inside onCreate()

                    try {
                        // Create a URL for the desired page
                        URL url = new URL("https://api.ipify.org/"); //My text file location
                        //First open the connection
                        HttpURLConnection conn=(HttpURLConnection) url.openConnection();
                        conn.setConnectTimeout(60000); // timing out in a minute

                        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                        //t=(TextView)findViewById(R.id.TextView1); // ideally do this in onCreate()
                        String str;
                        while ((str = in.readLine()) != null) {
                            urls.add(str);
                        }

                        in.close();
                    } catch (Exception e) {
                        Log.d("MyTag",e.toString());
                    }


                }
            }).start();}


    public static String GetLocalIPAddress(Context context) {
        NetworkInfo info = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (info != null && info.isConnected()) {
            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {//Currently use 2G/3G/4G network
                try {
                    //Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();
                    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                        NetworkInterface intf = en.nextElement();
                        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                            InetAddress inetAddress = enumIpAddr.nextElement();
                            if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                return inetAddress.getHostAddress();
                            }
                        }
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                }}}return null;
    }
    
	public void startOrStopTunnel(Activity activity) {
		if (SkStatus.isTunnelActive()) {
			TunnelManagerHelper.stopSocksHttp(activity);
            if(bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED){
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                iv1.animate().setDuration(500).rotation(0);
			}
            //pauseChronometer();
            resetChronometer();
            chronometer.stop();
			chronometer.setText("00h:00m:00s");
            payloadSpinner.setEnabled(true);
			serverSpinner.setEnabled(true);
            
		}
		else {
			// oculta teclado se vísivel, tá com bug, tela verde
			//Utils.hideKeyboard(activity);
			
			Settings config = new Settings(activity);
			
			if (config.getPrefsPrivate()
					.getBoolean(Settings.CONFIG_INPUT_PASSWORD_KEY, false)) {
				if (inputPwUser.getText().toString().isEmpty() || 
						inputPwPass.getText().toString().isEmpty()) {
					Toast.makeText(this, R.string.error_userpass_empty, Toast.LENGTH_SHORT)
						.show();
					return;
                    
                    
				}
			}
			Intent intent = new Intent(activity, LaunchVpn.class);
            intent.setAction(Intent.ACTION_MAIN);

            payloadSpinner.setEnabled(false);
            serverSpinner.setEnabled(false);
            if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
				iv1.animate().setDuration(500).rotation(180);
            }
            chronometer.setText("00h:00m:00s");
            //startChronometer();
			chronometer.start();
            
			activity.startActivity(intent);
		}
	}
    public void resetChronometer() {
        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseOffset = 0;
    }
    public void startChronometer() {
        if (!running) {
            chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
            chronometer.start();
            running = true;
        }
    }
    public void pauseChronometer() {
        if (running) {
            chronometer.stop();
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
            running = false;
        }
    }
	private void setPayloadSwitch(int tunnelType, boolean isCustomPayload) {
        SharedPreferences prefs = mConfig.getPrefsPrivate();

        boolean isRunning = SkStatus.isTunnelActive();

        customPayloadSwitch.setChecked(isCustomPayload);

        if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
            payloadEdit.setEnabled(false);

            if (mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY).isEmpty()) {
                customPayloadSwitch.setEnabled(false);
            }
            else {
                customPayloadSwitch.setEnabled(!isRunning);
            }

            if (!isCustomPayload && tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY)
                payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
            else
                payloadEdit.setText("*******");
        }
        else {
            customPayloadSwitch.setEnabled(!isRunning);

            if (isCustomPayload) {
                payloadEdit.setText(mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY));
                payloadEdit.setEnabled(!isRunning);
            }
            else if (tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY) {
                payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
                payloadEdit.setEnabled(false);
            }
        }

        if (isCustomPayload || tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY) {
            payloadLayout.setVisibility(View.VISIBLE);
        }
        else {
            payloadLayout.setVisibility(View.GONE);
        }
    }

    public void setStarterButton(Button starterButton, Activity activity) {
        String state = SkStatus.getLastState();
        boolean isRunning = SkStatus.isTunnelActive();

        if (starterButton != null) {
            int resId;

            SharedPreferences prefsPrivate = new Settings(activity).getPrefsPrivate();

            if (ConfigParser.isValidadeExpirou(prefsPrivate
                                               .getLong(Settings.CONFIG_VALIDADE_KEY, 0))) {
                resId = R.string.expired;
                starterButton.setEnabled(false);

                if (isRunning) {
                    startOrStopTunnel(activity);
                }
            }
            else if (prefsPrivate.getBoolean(Settings.BLOQUEAR_ROOT_KEY, false) &&
                     ConfigParser.isDeviceRooted(activity)) {
                resId = R.string.blocked;
                starterButton.setEnabled(false);

                Toast.makeText(activity, R.string.error_root_detected, Toast.LENGTH_SHORT)
                    .show();

                if (isRunning) {
                    startOrStopTunnel(activity);
                }
            }
            else if (SkStatus.SSH_INICIANDO.equals(state)) {
                   spaceNavigationView.changeCenterButtonIcon(R.drawable.ic_stop_vpn); 
                resId = R.string.stop;
                dataThread = new Thread(new MyThreadClass());
                //new edsongraphflip(SocksHttpMainActivity.this, "start");
                dataThread.setName("showDataGraph");
                dataThread.start();
                starterButton.setEnabled(false);
                graph.start();
            }
            else if (SkStatus.SSH_PARANDO.equals(state)) {
                      spaceNavigationView.changeCenterButtonIcon(R.drawable.ic_start_vpn);
                resId = R.string.state_stopping;
                //starterButton.setEnabled(false);
                dataThread = new Thread(new MyThreadClass());
                dataThread.setName("stopDataGraph");
                starterButton.setEnabled(false);
                graph.stop();
			}
            else {
                resId = isRunning ? R.string.stop : R.string.start;
                starterButton.setEnabled(true);
            }

            starterButton.setText(resId);
        }
    }



    @Override
    public void onPostCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

    }

    private boolean isMostrarSenha = false;

    @Override
    public void onClick(View p1)
    {
        SharedPreferences prefs = mConfig.getPrefsPrivate();

        switch (p1.getId()) {
            case R.id.activity_starterButtonMain:
                doSaveData();
                loadServerData();
                startOrStopTunnel(this);
                graph.start();
                break;

            case R.id.activity_mainInputProxyLayout:
                if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
                    doSaveData();

                    DialogFragment fragProxy = new ProxyRemoteDialogFragment();
                    fragProxy.show(getSupportFragmentManager(), "proxyDialog");
                }
                break;

            case R.id.activity_mainAutorText:
                String url = "http://t.me/SlipkProjects";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(intent, getText(R.string.open_with)));
				break;

            case R.id.activity_mainInputShowPassImageButton:
                isMostrarSenha = !isMostrarSenha;
                if (isMostrarSenha) {
                    inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    inputPwShowPass.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_visibility_black_24dp));
                }


                else {
                    inputPwPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    inputPwShowPass.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_visibility_off_black_24dp));
                }
                break;
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup p1, int p2)
    {
        SharedPreferences.Editor edit = mConfig.getPrefsPrivate().edit();


        switch (p1.getCheckedRadioButtonId()) {
            case R.id.activity_mainSSHDirectRadioButton:
                edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
                proxyInputLayout.setVisibility(View.GONE);
                break;

            case R.id.activity_mainSSHProxyRadioButton:
                edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY);
                proxyInputLayout.setVisibility(View.VISIBLE);
                break;
        }

        edit.apply();

        doSaveData();
        doUpdateLayout();

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
    {

        SharedPreferences prefs = mConfig.getPrefsPrivate();
        SharedPreferences.Editor edit = prefs.edit();



        switch (buttonView.getId()) {
            case R.id.activity_mainCustomPayloadSwitch:
                edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, !isChecked);
                setPayloadSwitch(prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT), isChecked);
                break;
        }

        edit.apply();

        doSaveData();
    }

    protected void showBoasVindas() {
        nops = new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.WARNING_TYPE);	
        nops.setTitleText(getString(R.string.attention));
        nops.setContentText(getString(R.string.first_start_msg));
        nops.setConfirmText(getString(R.string.ok));   
        nops.show();        
    }   




    @Override
    public void updateState(final String state, String msg, int localizedResId, final ConnectionStatus level, Intent intent)
    {
        mHandler.post(new Runnable() {
                @Override
                public void run() {
                    doUpdateLayout();
                    if (SkStatus.isTunnelActive()){

                        if (level.equals(ConnectionStatus.LEVEL_CONNECTED)){
                            status_view1.setText(R.string.connected);   
                            }
                        if (level.equals(ConnectionStatus.LEVEL_NOTCONNECTED)){
                            status_view1.setText(R.string.servicestop);
                        }   

                        if (level.equals(ConnectionStatus.LEVEL_CONNECTING_SERVER_REPLIED)){
                            status_view1.setText(R.string.authenticating);
                        }       

                        if (level.equals(ConnectionStatus.LEVEL_CONNECTING_NO_SERVER_REPLY_YET)){
                            status_view1.setText(R.string.connecting);
                        }           
                        if (level.equals(ConnectionStatus.LEVEL_AUTH_FAILED)){
                            status_view1.setText(R.string.authfailed);
                        }                   
                        if (level.equals(ConnectionStatus.UNKNOWN_LEVEL)){
                            status_view1.setText(R.string.disconnected);
                            } 
                        /*if (level.equals(ConnectionStatus.LEVEL_RECONNECTING)){
                         status.setText(R.string.reconnecting);*/
                    }               
                    if (level.equals(ConnectionStatus.LEVEL_NONETWORK)){
                        status_view1.setText(R.string.nonetwork);
                    }           





                }});

        switch (state) {
            case SkStatus.SSH_CONECTADO:
                // carrega ads banner
                if (adsBannerView != null && TunnelUtils.isNetworkOnline(SocksHttpMainActivity.this)) {
                    adsBannerView.setAdListener(new AdListener() {
                            @Override
                            public void onAdLoaded() {
                                if (adsBannerView != null && !isFinishing()) {
                                    adsBannerView.setVisibility(View.VISIBLE);
                                }
                            }
                        });
                    adsBannerView.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // carrega ads interestitial
                                AdsManager.newInstance(getApplicationContext())
                                    .loadAdsInterstitial();
                                // ads banner
                                if (adsBannerView != null && !isFinishing()) {
                                    adsBannerView.loadAd(new AdRequest.Builder()
                                                         .build());
                                }
                            }
                        }, 5000);
                }
                break;
        }}
    /**
     * Recebe locais Broadcast
     */

    private BroadcastReceiver mActivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null)
                return;

            if (action.equals(UPDATE_VIEWS) && !isFinishing()) {
                doUpdateLayout();
            }
            else if (action.equals(OPEN_LOGS)) {

            }
        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        // Menu Itens
        switch (item.getItemId()) {
            case R.id.configUpdate:
                updateConfig(false);
                break;
            case R.id.payloadGenerator:
                updateConfig(false);
                break;
            case R.id.miLimparConfig:
                if (!SkStatus.isTunnelActive()) {
                    DialogFragment dialog = new ClearConfigDialogFragment();
                    dialog.show(getSupportFragmentManager(), "alertClearConf");
                } else {
                    Toast.makeText(this, R.string.error_tunnel_service_execution, Toast.LENGTH_SHORT)
                        .show();
                }
                break;

            case R.id.miSettings:
                Intent intentSettings = new Intent(this, ConfigGeralActivity.class);
                //intentSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intentSettings);
                break;

            case R.id.miSettingImportar:
                if (SkStatus.isTunnelActive()) {
                    Toast.makeText(this, R.string.error_tunnel_service_execution,
                                   Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent intentImport = new Intent(this, ConfigImportFileActivity.class);
                    startActivity(intentImport);
                }
                break;

            case R.id.miSettingExportar:
                SharedPreferences prefs = mConfig.getPrefsPrivate();

                if (SkStatus.isTunnelActive()) {
                    Toast.makeText(this, R.string.error_tunnel_service_execution,
                                   Toast.LENGTH_SHORT).show();
                }
                else if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
                    Toast.makeText(this, R.string.error_settings_blocked,
                                   Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent intentExport = new Intent(this, ConfigExportFileActivity.class);
                    startActivity(intentExport);
                }
                break;

                // logs opções
            case R.id.miLimparLogs:
                //mDrawer.clearLogs();
                break;

            case R.id.miExit:
                if (Build.VERSION.SDK_INT >= 16) {
                    finishAffinity();
                }

                System.exit(0);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

        }

        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-) 

                }

                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            MsgAdmin.setText(result);
        }
	}

    


    @Override
    public void onResume() {
        super.onResume();

        updateHeaderCallback();
         SkStatus.addStateListener(this);

        if (adsBannerView != null) {
            adsBannerView.resume();
        }
    }
    @Override
    protected void onPause()
    {
        super.onPause();

        
        doSaveData();

        SkStatus.removeStateListener(this);

        if (adsBannerView != null) {
            adsBannerView.pause();
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        //mDrawer.onDestroy();

        LocalBroadcastManager.getInstance(this)
            .unregisterReceiver(mActivityReceiver);

        if (adsBannerView != null) {
            adsBannerView.destroy();
        }
    }


    /**
     * DrawerLayout Listener
     */

    @Override
    public void onDrawerOpened(View view) {
        if (view.getId() == R.id.activity_mainLogsDrawerLinear) {
            toolbar_main.getMenu().clear();
            getMenuInflater().inflate(R.menu.logs_menu, toolbar_main.getMenu());
        }
    }

    @Override
    public void onDrawerClosed(View view) {
        if (view.getId() == R.id.activity_mainLogsDrawerLinear) {
            toolbar_main.getMenu().clear();
            getMenuInflater().inflate(R.menu.main_menu, toolbar_main.getMenu());
        }
    }

    @Override
    public void onDrawerStateChanged(int stateId) {}
    @Override
    public void onDrawerSlide(View view, float p2) {}


    /**
     * Utils
     */

    public static void updateMainViews(Context context) {
        Intent updateView = new Intent(UPDATE_VIEWS);
        LocalBroadcastManager.getInstance(context)
            .sendBroadcast(updateView);
    }

    @Override
    public void onBackPressed()
    {


        new SweetAlertDialog(SocksHttpMainActivity.this, SweetAlertDialog.WARNING_TYPE)
            .setTitleText(getString(R.string.attention))
            .setContentText(getString(R.string.alert_exit))
            .setConfirmText(getString(R.string.exit))
            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {

                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog)
                {
                    // TODO: Implement this method

                    Utils.exitAll(SocksHttpMainActivity.this);
                }})
            .setCancelText(getString(R.string.minimize))
            .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener(){

                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog)
                {
                    // TODO: Implement this method
                    Intent startMain = new Intent(Intent.ACTION_MAIN);
                    startMain.addCategory(Intent.CATEGORY_HOME);
                    startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(startMain);
                }


            })

            .show();
    }}
    
    

