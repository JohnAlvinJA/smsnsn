package net.splash.android;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.mikhaellopez.circularfillableloaders.CircularFillableLoaders;
import net.splash.android.R;

public class JaSplash extends Activity {
 CircularFillableLoaders circularFillableLoaders;
    private Handler handler = new Handler();
    int sleep = 0;
      Handler handlerz = new Handler();    
    private int progressStatus = 0;
    int status = 0;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ja_splash);
  final TextView tv = (TextView)findViewById(R.id.text);
      final ProgressBar pb = (ProgressBar)findViewById(R.id.progress);
      
        new Thread(new Runnable() {
                @Override
                public void run() {
                  while(progressStatus < 100){


                      // Update the progress status
                      progressStatus +=1;

                      // Try to sleep the thread for 20 milliseconds

                      try{
                          Thread.sleep(100);
                      }catch(InterruptedException e){
                          e.printStackTrace();
                      }

                      // Update the progress bar

                      handler.post(new Runnable() {
                              @Override
                              public void run() {
                                  pb.setProgress(progressStatus);

                                  // Show the progress on TextView

                                  tv.setText(progressStatus+"");
                                  if (progressStatus == 100) {
                                      startActivity(new Intent(JaSplash.this, MainActivity.class));
                                      finish();
                              }}
                          });
                  }
              }
          }).start(); // Start the operation
		circularFillableLoaders = ((CircularFillableLoaders) findViewById(R.id.circularFillableLoaders));
		circularFillableLoaders.setProgress(100);
		circularFillableLoaders.setImageResource(R.drawable.ic_launcher);
		new Thread(new Runnable() {
				public void run() {
					while (JaSplash.this.sleep < 100) {
						JaSplash com_bytesbridge_learnAndroid_splash_screen = JaSplash.this;
						com_bytesbridge_learnAndroid_splash_screen.sleep = com_bytesbridge_learnAndroid_splash_screen.sleep + 3;						
						JaSplash.this.handler.post(new Runnable() {
								public void run() {
									circularFillableLoaders.setProgress(JaSplash.this.sleep);
								}
							});
						try {
							Thread.sleep(110);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}).start();
	
	}
}
